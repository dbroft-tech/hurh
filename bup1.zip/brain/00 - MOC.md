---
type: moc
project: awmi-clone
tags: [moc, index]
---

# 🧠 AWMI Clone — Brain Vault

## Decisions
- [[Tech Stack]]
- [[Design System Decisions]]
- [[Features Scope]]
- [[Open Questions]]

## Architecture
- [[Route Map]]
- [[Component Tree]]
- [[Data Flow]]

## Features
- [[Homepage]]
- [[Watch]]
- [[Listen]]
- [[Read]]
- [[Healing]]
- [[Give]]
- [[Events]]
- [[About]]
- [[Living Commentary]]
- [[Browse Teachings]]

## Design System
- [[Brand Guide]]
- [[Mega Menu]]
- [[Layout]]
- [[Components]]

## Notes
- [[AWMI Feature Inventory]]
- [[Milestones]]
