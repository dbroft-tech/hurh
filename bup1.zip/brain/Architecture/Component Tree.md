---
type: architecture
tags: [components, architecture]
---

# Component Tree

## Layout Components

```
RootLayout
├── Header
│   ├── Logo
│   ├── MegaMenu (desktop)
│   │   ├── WatchMenu
│   │   ├── ListenMenu
│   │   ├── ReadMenu
│   │   ├── ResourcesMenu
│   │   └── AboutMenu
│   ├── HamburgerMenu (mobile)
│   ├── SearchBar
│   └── GiveButton
├── MainContent
│   └── {children}
└── Footer
    ├── ContactInfo
    ├── SocialLinks
    ├── LegalLinks
    └── MinistryLogos
```

## Feature Components

### Homepage
```
HomePage
├── HeroSection
├── ThroughTheBibleSection
├── QuickLinksBar
├── ResourcesSlider
├── FeaturedTestimony
├── ContentBlocks (Watch, Listen, Read, GTN)
├── VideoStoriesSection
├── DonationCTA
└── MinistriesGrid
```

### Watch
```
WatchPage
├── MediaHubHeader
├── VideoPlayer
│   ├── VideoElement
│   ├── CustomControls
│   │   ├── PlayPause
│   │   ├── ProgressBar
│   │   ├── VolumeControl
│   │   ├── FullscreenToggle
│   │   └── TimeDisplay
│   └── ErrorOverlay
├── EpisodeDescription
├── CategoryTabs
└── EpisodeGrid
    └── EpisodeCard (thumbnail, title, duration)
```

### Listen
```
ListenPage
├── AudioLibraryHeader
├── SearchFilterBar
│   ├── SearchInput
│   └── CategoryDropdown
└── TrackList
    └── TrackCard
        ├── PlayButton
        ├── TrackInfo (title, speaker, description)
        ├── Duration
        └── ListenButton
```

### Read
```
ReadPage
├── DevotionalHeader
├── DevotionalLayout
│   ├── CalendarPicker
│   │   ├── MonthYearHeader
│   │   ├── WeekdayHeaders
│   │   ├── DayGrid
│   │   └── JumpToToday
│   └── DevotionalCard
│       ├── DateDisplay
│       ├── ScriptureBadge
│       ├── Title
│       ├── VerseBlock
│       ├── Commentary
│       └── PrayerBlock
├── CommentarySearch
│   ├── SearchInput
│   └── ResultCard
│       ├── Reference
│       ├── Verse
│       ├── GreekNote
│       └── AndrewNote
```

### Healing
```
HealingPage
├── HealingHeader
├── HealingLayout
│   ├── ScripturesPanel
│   │   ├── CategoryTabs
│   │   └── ScriptureCards
│   │       ├── Reference
│   │       ├── Verse
│   │       └── Declaration
│   └── PrayerFormPanel
│       ├── NameInput
│       ├── EmailInput
│       ├── ConditionSelect
│       ├── MessageTextarea
│       └── SubmitButton
├── TestimoniesSection
│   ├── VideoTestimonies
│   └── TextTestimonies
├── HealingSchoolInfo
└── PhoneMinistryCTA
```

### Give
```
GivePage
├── GiveHeader
├── GiveLayout
│   ├── BenefitCalculator
│   │   ├── SliderControl
│   │   ├── CurrentTierCard
│   │   └── BenefitsList
│   └── DonationForm
│       ├── MonthlyOneTimeToggle
│       ├── PresetAmounts
│       ├── CustomAmountInput
│       └── SubmitButton
├── GuestbookTestimonials
└── OtherWaysToGive
```

## Shared Components

```
components/
├── ui/
│   ├── Button
│   ├── Card
│   ├── Input
│   ├── Select
│   ├── Textarea
│   ├── Badge
│   ├── Modal
│   ├── Tabs
│   └── Slider
├── layout/
│   ├── Container
│   ├── Grid
│   ├── Stack
│   └── Section
├── media/
│   ├── VideoPlayer
│   ├── AudioPlayer
│   ├── Image
│   └── Embed
└── common/
    ├── SearchBar
    ├── CategoryFilter
    ├── Pagination
    ├── Skeleton
    └── EmptyState
```
