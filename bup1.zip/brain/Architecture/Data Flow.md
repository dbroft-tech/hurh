---
type: architecture
tags: [data-flow, architecture]
---

# Data Flow

## Overview

This is a **static site** with no backend. All data is hardcoded in TypeScript files.

```
┌─────────────────────────────────────────────────┐
│                   Layout                        │
│  ┌─────────┐  ┌──────────┐  ┌────────────┐     │
│  │ Header  │  │  Main    │  │  Footer    │     │
│  │ (Nav)   │  │ Content  │  │            │     │
│  └─────────┘  └──────────┘  └────────────┘     │
│                      │                          │
│              ┌───────┴───────┐                  │
│              │  Page Content │                  │
│              │  (Static Data)│                  │
│              └───────────────┘                  │
└─────────────────────────────────────────────────┘
```

## Data Sources

### Static Data Files

```
src/data/
├── episodes.ts          # Video episodes (6 items)
├── tracks.ts            # Audio tracks (8 items)
├── devotionals.ts       # Daily devotionals (4 + fallback)
├── commentaries.ts      # Commentary entries (3 items)
├── scriptures.ts        # Healing scriptures (5 items)
├── tiers.ts             # Partnership tiers (4 items)
├── ministries.ts        # Ministry cards (5 items)
├── testimonies.ts       # Testimonials (3 items)
└── topics.ts            # Teaching topics (10+ items)
```

### Data Flow Per Feature

#### Watch Page
```
episodes.ts → WatchPage → VideoPlayer (state: currentEpisode)
                        → EpisodeGrid (filter by category)
                        → CategoryTabs (state: activeCategory)
```

#### Listen Page
```
tracks.ts → ListenPage → TrackList (filter by search/category)
                       → TrackCard → playTrack(track)
```

#### Read Page
```
devotionals.ts → ReadPage → CalendarPicker (state: selectedDate)
                          → DevotionalCard (get devotional by date)
commentaries.ts → CommentarySearch (state: query → result)
```

#### Healing Page
```
scriptures.ts → ScripturesPanel (filter by category)
              → CategoryTabs (state: activeTab)
PrayerForm → FormData (state: name, email, condition, message)
           → SubmissionState (state: formSubmitted)
```

#### Give Page
```
tiers.ts → BenefitCalculator (state: partnerAmount → currentTier)
         → DonationForm (state: giveType, presetAmount, customAmount)
```

## State Management

### Zustand Store (Global)

```typescript
// No global state needed for v1
// All state is local to each page
```

### Local State (Per Page)

| Page | State | Type |
|------|-------|------|
| Watch | currentEpisode, activeCategory, isPlaying | useState |
| Listen | searchQuery, selectedCategory, currentTrack | useState |
| Read | selectedDate, searchQuery, searchResult | useState |
| Healing | activeTab, formSubmitted, formData | useState |
| Give | partnerAmount, giveType, presetAmount, isSubmitted | useState |

## Media Playback

### Video (Watch Page)
- Native `<video>` element
- Local state: `videoRef`, `isPlaying`, `currentTime`, `duration`
- Custom overlay controls
- No global audio state

### Audio (Listen Page)
- Native `<Audio>` element per track (browser handles)
- Local state per track card
- Click play → `new Audio(url).play()`
- No persistent player bar

## Search Implementation

### Client-Side Filter
```typescript
// Simple array filter
const results = data.filter(item => 
  item.title.toLowerCase().includes(query.toLowerCase()) ||
  item.description.toLowerCase().includes(query.toLowerCase())
);
```

### No External Search Library
- Direct string matching
- Case-insensitive
- Real-time filtering
