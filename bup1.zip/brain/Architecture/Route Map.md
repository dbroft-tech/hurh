---
type: architecture
tags: [routes, architecture]
---

# Route Map

## Public Routes

| Route | Page | Layout |
|-------|------|--------|
| `/` | Homepage | Default |
| `/watch` | Media Hub | Default |
| `/listen` | Audio Library | Default |
| `/read` | Daily Devotional | Default |
| `/healing` | Healing Center | Default |
| `/give` | Partnership/Donate | Default |
| `/about` | About Ministry | Default |
| `/about/beliefs` | Statement of Faith | Default |
| `/about/history` | Ministry History | Default |
| `/contact` | Contact Form | Default |
| `/search` | Search Results | Default |
| `/browse` | Browse Teachings | Default |

## Future Routes (v2)

| Route | Page |
|-------|------|
| `/events` | Events Calendar |
| `/events/[id]` | Event Detail |
| `/watch/[series]` | Series Episodes |
| `/watch/[series]/[episode]` | Episode Detail |
| `/read/[date]` | Specific Devotional |
| `/living-commentary` | Commentary Tool |
| `/espanol` | Spanish Content |

## Route Groups

```
app/
├── layout.tsx              # Root layout (header, footer)
├── page.tsx                # Homepage
├── watch/
│   └── page.tsx            # Media hub
├── listen/
│   └── page.tsx            # Audio library
├── read/
│   ├── page.tsx            # Devotional (today)
│   └── [date]/
│       └── page.tsx        # Specific date
├── healing/
│   └── page.tsx            # Healing center
├── give/
│   └── page.tsx            # Give page
├── about/
│   ├── page.tsx            # About overview
│   ├── beliefs/
│   │   └── page.tsx
│   └── history/
│       └── page.tsx
├── contact/
│   └── page.tsx
├── search/
│   └── page.tsx
└── browse/
    └── page.tsx
```
