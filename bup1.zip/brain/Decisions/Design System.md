---
type: decision
status: confirmed
tags: [design, decisions]
---

# Design System Decisions

## Brand Colors (from AWMI)

| Token | Hex | Usage |
|-------|-----|-------|
| --primary | #C41E3A | AWMI Red — CTAs, active states |
| --secondary | #1E3A5F | Dark blue — headers, accents |
| --accent | #D4A843 | Gold — highlights, badges |
| --bg-primary | #FFFFFF | Page background |
| --bg-secondary | #F8F9FA | Card backgrounds |
| --bg-dark | #1A1A2E | Dark sections, footer |
| --text-primary | #1A1A2E | Body text |
| --text-secondary | #6B7280 | Muted text |
| --text-on-primary | #FFFFFF | Text on red/blue |

## Typography

| Element | Font | Weight | Size |
|---------|------|--------|------|
| Display | Merriweather | 700 | 2.5-3.5rem |
| Heading 1 | Merriweather | 700 | 2-2.5rem |
| Heading 2 | Inter | 600 | 1.5-1.75rem |
| Heading 3 | Inter | 600 | 1.25rem |
| Body | Inter | 400 | 1rem |
| Small | Inter | 400 | 0.875rem |
| Caption | Inter | 500 | 0.75rem |

## Confirmed UX Decisions

| Feature | Decision |
|---------|----------|
| Navigation | Mega menu (multi-column dropdown) |
| Video player | Custom controls overlay |
| Audio player | Inline per-page (not persistent) |
| Devotional | Calendar picker UI |
| Testimonials | Both video embeds + text cards |
| Give page | Both slider calculator + form |
| Search | Client-side filter |
| Mobile nav | Hamburger menu |
