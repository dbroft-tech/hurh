---
type: decision
status: confirmed
tags: [scope, decisions]
---

# Features Scope

## ✅ Included (v1)

### Global
- Sticky header with mega menu
- Hamburger menu (mobile)
- Footer with contact, social, legal
- Sitewide search (client-side)
- Responsive design (mobile-first)

### Homepage
- Hero section with CTA
- "Through the Bible" section
- Quick links bar
- Resources carousel/slider
- Featured testimony
- 4 content blocks (Watch, Listen, Read, GTN)
- Video stories section
- Donation CTA with scripture
- Ministries grid (5 cards)

### Watch
- Media hub page
- Video player with custom controls
- Episode browser (Mon-Fri)
- Category tabs (All, TV, Healing, Destiny, Events)
- Episode grid (thumbnails)
- Series descriptions

### Listen
- Audio teachings library
- Inline audio player per track
- Category filter
- Search by title/description
- Track list with play buttons
- Duration display

### Read
- Daily devotional display
- Calendar picker (month grid)
- Devotional content (scripture, commentary, prayer)
- Prev/next navigation
- Commentary search tool

### Healing
- Overview with expandable text
- Healing scriptures list
- Scripture categories (General, Terminal, Chronic, Mental)
- Prayer request form
- Healing testimonies (video + text)
- Healing School info
- Phone ministry CTA

### Give
- Partnership benefit calculator (slider)
- Tier display (4 levels)
- Donation form (visual only)
- Monthly/one-time toggle
- Guestbook testimonials
- "Other Ways to Give" section

### About
- Ministry overview
- Beliefs statement
- History timeline
- Contact form
- Staff section

### Living Commentary
- Search tool
- Sample commentary entries
- Verse display
- Greek word study
- Andrew's notes

### Browse Teachings
- Topic grid
- Filter by category
- Teaching cards with thumbnails

## ❌ Excluded (v1)
- Real payment processing
- User authentication
- Partner portal
- Store/e-commerce
- Events calendar (future)
- Multi-language
- Podcast player
- Blog
- Newsletter backend
- Living Commentary (full 28k notes)
