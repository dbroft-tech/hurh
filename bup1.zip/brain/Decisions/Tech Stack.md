---
type: decision
status: confirmed
tags: [tech-stack, decisions]
---

# Tech Stack

## Confirmed

| Layer | Choice | Reason |
|-------|--------|--------|
| Framework | Next.js 16 (App Router) | Existing project setup |
| Language | TypeScript 5 | Type safety |
| Styling | Tailwind CSS 4 | Fast prototyping |
| State | Zustand | Lightweight, simpler than Context |
| Icons | Lucide React | Tree-shakeable, modern |
| Fonts | Inter (body) + Merriweather (headings) | Free, professional |

## Not Included (v1)
- Backend / Database
- Authentication
- Real payments
- CMS integration
- Analytics
