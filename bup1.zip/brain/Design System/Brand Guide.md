---
type: design
tags: [brand, design-system]
---

# Brand Guide

## Color Palette

### Primary Colors
| Name | Hex | RGB | Usage |
|------|-----|-----|-------|
| AWMI Red | #C41E3A | 196, 30, 58 | CTAs, primary actions |
| Dark Blue | #1E3A5F | 30, 58, 95 | Headers, dark sections |
| Gold | #D4A843 | 212, 168, 67 | Highlights, badges |

### Neutral Colors
| Name | Hex | Usage |
|------|-----|-------|
| White | #FFFFFF | Page background |
| Off-White | #F8F9FA | Card backgrounds |
| Light Gray | #E5E7EB | Borders |
| Gray | #6B7280 | Secondary text |
| Dark | #1A1A2E | Primary text |
| Black | #000000 | Footer background |

### Semantic Colors
| Name | Hex | Usage |
|------|-----|-------|
| Success | #10B981 | Success states |
| Warning | #F59E0B | Warning states |
| Error | #EF4444 | Error states |
| Info | #3B82F6 | Info states |

## Typography

### Font Families
```css
--font-heading: 'Merriweather', serif;
--font-body: 'Inter', sans-serif;
```

### Type Scale
| Name | Size | Weight | Line Height | Font |
|------|------|--------|-------------|------|
| Display | 3.5rem | 700 | 1.1 | Merriweather |
| H1 | 2.5rem | 700 | 1.2 | Merriweather |
| H2 | 1.75rem | 600 | 1.3 | Inter |
| H3 | 1.25rem | 600 | 1.4 | Inter |
| Body | 1rem | 400 | 1.6 | Inter |
| Small | 0.875rem | 400 | 1.5 | Inter |
| Caption | 0.75rem | 500 | 1.4 | Inter |

## Spacing Scale
| Token | Value |
|-------|-------|
| --space-xs | 0.25rem |
| --space-sm | 0.5rem |
| --space-md | 1rem |
| --space-lg | 1.5rem |
| --space-xl | 2rem |
| --space-2xl | 3rem |
| --space-3xl | 4rem |

## Border Radius
| Token | Value |
|-------|-------|
| --radius-sm | 4px |
| --radius-md | 8px |
| --radius-lg | 12px |
| --radius-xl | 16px |
| --radius-full | 9999px |

## Shadows
| Token | Value |
|-------|-------|
| --shadow-sm | 0 1px 2px rgba(0,0,0,0.05) |
| --shadow-md | 0 4px 6px rgba(0,0,0,0.1) |
| --shadow-lg | 0 10px 15px rgba(0,0,0,0.1) |
| --shadow-xl | 0 20px 25px rgba(0,0,0,0.15) |
