---
type: design
tags: [components, design-system]
---

# Components

## Buttons

### Primary Button
```css
.btn-primary {
  background: #C41E3A;
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  transition: all 0.2s;
}
.btn-primary:hover {
  background: #A3182E;
  transform: translateY(-1px);
}
```

### Secondary Button
```css
.btn-secondary {
  background: #1E3A5F;
  color: white;
  /* same as primary */
}
```

### Outline Button
```css
.btn-outline {
  background: transparent;
  border: 2px solid #C41E3A;
  color: #C41E3A;
}
.btn-outline:hover {
  background: #C41E3A;
  color: white;
}
```

### Ghost Button
```css
.btn-ghost {
  background: transparent;
  color: #1A1A2E;
}
.btn-ghost:hover {
  background: #F3F4F6;
}
```

### Sizes
| Size | Padding | Font Size |
|------|---------|-----------|
| sm | 0.5rem 1rem | 0.875rem |
| md | 0.75rem 1.5rem | 1rem |
| lg | 1rem 2rem | 1.125rem |

## Cards

### Basic Card
```css
.card {
  background: white;
  border: 1px solid #E5E7EB;
  border-radius: 12px;
  padding: 1.5rem;
  transition: all 0.2s;
}
.card:hover {
  box-shadow: 0 10px 15px rgba(0,0,0,0.1);
  transform: translateY(-2px);
}
```

### Featured Card
```css
.card-featured {
  border: 2px solid #C41E3A;
  background: linear-gradient(135deg, #FFF5F5, #FFFFFF);
}
```

## Forms

### Input
```css
.input {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1px solid #E5E7EB;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.2s;
}
.input:focus {
  outline: none;
  border-color: #C41E3A;
  box-shadow: 0 0 0 3px rgba(196, 30, 58, 0.1);
}
```

### Select
```css
.select {
  /* Same as input */
  appearance: none;
  background-image: url("chevron-down.svg");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  padding-right: 2.5rem;
}
```

### Textarea
```css
.textarea {
  /* Same as input */
  min-height: 120px;
  resize: vertical;
}
```

## Badges

### Category Badge
```css
.badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
}
.badge-primary {
  background: rgba(196, 30, 58, 0.1);
  color: #C41E3A;
}
.badge-secondary {
  background: rgba(30, 58, 95, 0.1);
  color: #1E3A5F;
}
.badge-accent {
  background: rgba(212, 168, 67, 0.1);
  color: #D4A843;
}
```

## Tabs

### Tab Bar
```css
.tabs {
  display: flex;
  gap: 0.5rem;
  border-bottom: 1px solid #E5E7EB;
  padding-bottom: 0.5rem;
}
.tab {
  padding: 0.5rem 1rem;
  border-radius: 8px 8px 0 0;
  font-weight: 500;
  color: #6B7280;
  cursor: pointer;
  transition: all 0.2s;
}
.tab:hover {
  color: #1A1A2E;
  background: #F3F4F6;
}
.tab-active {
  color: #C41E3A;
  border-bottom: 2px solid #C41E3A;
}
```

## Slider

### Range Input
```css
.slider {
  width: 100%;
  height: 8px;
  border-radius: 4px;
  background: #E5E7EB;
  appearance: none;
}
.slider::-webkit-slider-thumb {
  appearance: none;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #C41E3A;
  cursor: pointer;
}
```

## Modal

### Modal Container
```css
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}
.modal {
  background: white;
  border-radius: 16px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}
```

## Skeleton Loader

```css
.skeleton {
  background: linear-gradient(90deg, #F3F4F6 25%, #E5E7EB 50%, #F3F4F6 75%);
  background-size: 200% 100%;
  animation: skeleton-loading 1.5s infinite;
  border-radius: 8px;
}
@keyframes skeleton-loading {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
```
