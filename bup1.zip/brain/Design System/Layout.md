---
type: design
tags: [layout, design-system]
---

# Layout

## Page Structure

```
┌─────────────────────────────────────────────────────┐
│                    HEADER                           │
│  ┌───────────────────────────────────────────────┐  │
│  │ Logo    Nav Links              Search  Give   │  │
│  └───────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────┤
│                                                     │
│                    MAIN CONTENT                     │
│  ┌───────────────────────────────────────────────┐  │
│  │                                               │  │
│  │              {children}                       │  │
│  │                                               │  │
│  └───────────────────────────────────────────────┘  │
│                                                     │
├─────────────────────────────────────────────────────┤
│                    FOOTER                           │
│  ┌───────────────────────────────────────────────┐  │
│  │ Contact  |  Social  |  Legal  |  Logos        │  │
│  └───────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

## Container

| Breakpoint | Max Width | Padding |
|------------|-----------|---------|
| Default | 1200px | 1.5rem |
| sm (640px) | 640px | 1rem |
| md (768px) | 768px | 1.5rem |
| lg (1024px) | 1024px | 2rem |
| xl (1280px) | 1280px | 2rem |

## Grid System

### 12-Column Grid
```css
.grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 1.5rem;
}
```

### Common Layouts

#### 2-Column (70/30)
```css
.layout-sidebar {
  grid-template-columns: 2fr 1fr;
}
```

#### 2-Column (50/50)
```css
.layout-half {
  grid-template-columns: 1fr 1fr;
}
```

#### 3-Column
```css
.layout-three {
  grid-template-columns: repeat(3, 1fr);
}
```

#### 4-Column
```css
.layout-four {
  grid-template-columns: repeat(4, 1fr);
}
```

## Responsive Breakpoints

| Name | Width | Layout Changes |
|------|-------|----------------|
| Mobile | < 640px | Single column, hamburger nav |
| Tablet | 640-1024px | 2-column grids, side-by-side |
| Desktop | > 1024px | Full layout, mega menu |

## Section Spacing

| Type | Margin Top | Margin Bottom | Padding |
|------|------------|---------------|---------|
| Section | 4rem | 4rem | 0 |
| Section (dark) | 0 | 0 | 4rem 0 |
| Card Grid | 2rem | 2rem | 0 |
| Between Elements | 1.5rem | 0 | 0 |

## Header Specs

| Property | Value |
|----------|-------|
| Height | 80px |
| Position | Sticky, top: 0 |
| Z-index | 1000 |
| Background | White (with blur) |
| Border-bottom | 1px solid `--border-light` |

## Footer Specs

| Property | Value |
|----------|-------|
| Background | `--bg-dark` (#1A1A2E) |
| Text color | White |
| Padding | 4rem 0 2rem |
| Columns | 4 (responsive) |
| Social icons | White, hover: `--primary` |

## Card Specs

| Property | Value |
|----------|-------|
| Background | White |
| Border | 1px solid `--border-light` |
| Border-radius | `--radius-lg` |
| Padding | 1.5rem |
| Shadow | `--shadow-sm` |
| Hover | `--shadow-md`, translateY(-2px) |
