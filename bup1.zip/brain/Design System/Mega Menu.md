---
type: design
tags: [mega-menu, navigation, design-system]
---

# Mega Menu

## Structure

```
┌─────────────────────────────────────────────────────────────┐
│ Logo    Watch ▼  Listen ▼  Read ▼  Resources ▼  About ▼   [Search] [Give]
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Watch Menu (when open):                                    │
│  ┌──────────────┬──────────────┬──────────────┬───────────┐ │
│  │ TV Broadcast │ Browse       │ Video Stories│ Archives  │ │
│  │ - This Week  │ Teachings    │ - Healing    │ - Events  │ │
│  │ - Archives   │ - By Topic   │   Journeys   │ - Live    │ │
│  │ - Weekend    │ - Featured   │ - Testimonies│   Streams │ │
│  │              │              │ - Financial  │ - Bible   │ │
│  │              │              │              │   Study   │ │
│  └──────────────┴──────────────┴──────────────┴───────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Desktop Behavior

- Hover or click to open dropdown
- Multi-column layout (4 columns typical)
- Each column has header + links
- Click outside or Escape to close
- Smooth fade-in animation

## Mobile Behavior

- Hamburger menu icon (top right)
- Slide-in panel from right
- Accordion-style expandable sections
- Back button to return to main menu
- Full-height overlay

## Menu Items

### Watch
| Column 1 | Column 2 | Column 3 | Column 4 |
|----------|----------|----------|----------|
| TV Broadcast | Browse Teachings | Video Stories | Archives |
| - This Week's TV | - By Topic | - Healing Journeys | - Event Archives |
| - Daily Archives | - Featured | - Testimonies | - Live Streams |
| - Weekend Edition | | - Financial Breakthroughs | - Bible Study |
| | | - Grace Encounters | |

### Listen
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Audio Teachings | Archives | Podcasts |
| - Browse All | - Event Audio | - All Platforms |
| - Search | - Radio Shows | |
| | - Music | |

### Read
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Devotional | Study | Other |
| - Daily Devotional | - Commentary | - Newsletters |
| - Archive | - Bible Reading Plan | - Blog |
| - Subscribe | - Browse Teachings | - Survival Kit |

### Resources
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Popular | Spiritual | Support |
| - Top Teachings | - Receive Jesus | - Partners' Corner |
| - Healing Center | - Receive Holy Spirit | - FAQ |
| - Free Bible Studies | - Living Commentary | - Accommodations |

### About
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Ministry | People | Info |
| - Our Ministries | - Staff | - Contact Us |
| - Our Beliefs | - Board | - Careers |
| - Our History | | |

## Styling

### Dropdown Panel
- Background: White
- Shadow: `--shadow-lg`
- Border: 1px solid `--border-light`
- Border-radius: `--radius-md`
- Padding: `2rem`

### Menu Items
- Font: Inter, 0.875rem
- Color: `--text-primary`
- Hover: `--primary` color
- Icon: Chevron down (for parent items)

### Active State
- Background: `--bg-secondary`
- Color: `--primary`
- Border-left: 2px solid `--primary`
