---
type: feature
route: /about
tags: [about, feature]
---

# About

## Pages

### About Overview (`/about`)
- Ministry mission statement
- Key beliefs summary
- History timeline preview
- Links to sub-pages

### Beliefs (`/about/beliefs`)
- Statement of faith
- Core theological positions
- Scripture references

### History (`/about/history`)
- Ministry timeline (1976-present)
- Key milestones
- Photo gallery

## Content Structure

```typescript
interface MinistryInfo {
  mission: string;
  beliefs: string[];
  history: Milestone[];
  staff: StaffMember[];
}

interface Milestone {
  year: number;
  title: string;
  description: string;
}

interface StaffMember {
  name: string;
  role: string;
  image?: string;
}
```

## Key Milestones (Sample)

| Year | Event |
|------|-------|
| 1976 | Ministry founded |
| 1998 | Television ministry launched |
| 2000 | First Gospel Truth broadcast |
| 2009 | Moved to Woodland Park, CO |
| 2011 | Healing School launched |
| 2023 | 5,000th TV program |
| 2024 | Gospel Truth Network launched |
