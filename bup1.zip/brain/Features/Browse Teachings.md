---
type: feature
route: /browse
tags: [browse, teachings, feature]
---

# Browse Teachings

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Browse Teachings"                 │
├─────────────────────────────────────────────┤
│  Topic Filter (horizontal scroll)           │
│  [All] [Bible Studies] [Faith] [Healing]    │
│  [Prayer] [Identity] [Relationships] ...    │
├─────────────────────────────────────────────┤
│  Teaching Grid                              │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐       │
│  │  Image  │ │  Image  │ │  Image  │       │
│  │  Title  │ │  Title  │ │  Title  │       │
│  │  Topic  │ │  Topic  │ │  Topic  │       │
│  └─────────┘ └─────────┘ └─────────┘       │
└─────────────────────────────────────────────┘
```

## Teaching Topics

| Topic | Icon |
|-------|------|
| Bible Studies | 📖 |
| Faith | ✝️ |
| Finances | 💰 |
| God-Given Purpose | 🎯 |
| Grace | ❤️ |
| Healing | 🏥 |
| Holy Spirit | 🔥 |
| Identity in Christ | 👤 |
| Personal Relationships | 💑 |
| Prayer | 🙏 |
| Victorious Living | 🏆 |

## Teaching Data

```typescript
interface Teaching {
  id: string;
  title: string;
  topic: string;
  thumbnail: string;
  description: string;
  videoUrl?: string;
  audioUrl?: string;
}
```

## Filter Behavior
- Click topic → filter grid
- "All" shows everything
- Smooth transition on filter change
- Count badge on each topic
