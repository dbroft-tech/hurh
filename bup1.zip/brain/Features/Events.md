---
type: feature
route: /events
tags: [events, feature]
---

# Events Calendar

> **Status**: v2 feature — not included in initial build

## Planned Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Upcoming Events"                  │
├─────────────────────────────────────────────┤
│  Month Navigation: < August 2026 >          │
├─────────────────────────────────────────────┤
│  Event Cards                                │
│  ┌───────────────────────────────────────┐  │
│  │ 📅 Date                               │  │
│  │ 📍 Location                           │  │
│  │ Event Title                           │  │
│  │ Description                           │  │
│  │ [Register] [Learn More]               │  │
│  └───────────────────────────────────────┘  │
└─────────────────────────────────────────────┘
```

## Event Data Structure

```typescript
interface Event {
  id: string;
  title: string;
  date: string;
  endDate?: string;
  location: string;
  description: string;
  registrationUrl: string;
  category: 'conference' | 'livestream' | 'regional';
}
```

## Event Types
- **Conferences**: Multi-day events (Healing Is Here, For His Kingdom)
- **Live Streams**: Virtual events from AWM studio
- **Regional**: Local events in various cities
