---
type: feature
route: /give
tags: [give, feature]
---

# Give — Partnership & Donation

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Partnering in Grace & Truth"      │
├────────────────────┬────────────────────────┤
│  Benefit Calculator│  Donation Form          │
│  - Slider (10-500) │  - Monthly/One-time     │
│  - Current tier    │  - Preset amounts       │
│  - Benefits list   │  - Custom input         │
│                   │  - Submit button        │
├────────────────────┴────────────────────────┤
│  Guestbook Testimonials (3)                 │
├─────────────────────────────────────────────┤
│  Other Ways to Give                         │
│  - Stocks, IRAs, Real Estate, Wills         │
└─────────────────────────────────────────────┘
```

## Partnership Tiers (4)

| Tier | Range | Badge | Key Benefits |
|------|-------|-------|--------------|
| Grace Partner | $10-29/mo | Grace Circle | Newsletter, devotional, prayer |
| Gospel Truth Partner | $30-99/mo | Gospel Envoy | + 15% discount, MP3s, commentaries |
| Pillar Partner | $100-299/mo | Ministry Pillar | + Living Commentary, VIP seating |
| Foundation Pillar | $300+/mo | Foundation Circle | + Signed Bible, banquet, briefings |

## Benefit Calculator

### Slider Control
- Range: $10 to $500
- Step: $5
- Real-time tier update
- Display: "$XX /mo"

### Tier Card
- Tier name + badge
- Benefits list (bullet points)
- View transition on tier change

## Donation Form

### Give Type Toggle
- Monthly Gift (default)
- One-Time Gift

### Preset Amounts
- $20, $50, $100, $250
- Visual selection state

### Custom Amount
- Number input
- Updates slider + tier

### Submit Flow
1. Validate amount > 0
2. Show success state
3. "Support Again" button

## Guestbook Testimonials (3)

| Name | Location | Quote |
|------|----------|-------|
| C.H. | Sioux City, Iowa | "Helped me grow so much..." |
| L.D. | Romania | "My life completely changed..." |
| E.E.A. | Nigeria | "Corrected wrong perceptions..." |

## Other Ways to Give
- Stocks
- IRAs
- Real Estate
- Wills
- "Find Other Ways to Give" CTA
