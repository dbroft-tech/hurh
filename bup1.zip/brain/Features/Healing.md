---
type: feature
route: /healing
tags: [healing, feature]
---

# Healing Center

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Charis Healing Center"            │
├────────────────────┬────────────────────────┤
│  Scriptures Panel  │  Prayer Form Panel      │
│  - Category tabs   │  - Name input           │
│  - Scripture cards  │  - Email input          │
│    - Reference     │  - Condition select     │
│    - Verse text    │  - Message textarea     │
│    - Declaration   │  - Submit button        │
├────────────────────┴────────────────────────┤
│  More Recovery Journeys (2 cards)           │
├─────────────────────────────────────────────┤
│  Healing School Info                        │
├─────────────────────────────────────────────┤
│  Phone Ministry CTA                         │
└─────────────────────────────────────────────┘
```

## Healing Scriptures (5)

| Reference | Category | Theme |
|-----------|----------|-------|
| Isaiah 53:5 | general | Healing by His stripes |
| Proverbs 4:20-22 | chronic | God's word as medicine |
| Romans 8:11 | terminal | Holy Spirit quickening |
| 2 Timothy 1:7 | mental | Sound mind, no fear |
| Psalms 103:2-3 | general | Covenant benefits |

## Scripture Card Structure
- Reference (primary color, bold)
- Category badge (uppercase, muted)
- Verse text (italic, secondary color)
- Declaration block (amber header)

## Category Tabs
- All, General, Terminal, Chronic, Mental
- Filter scripture cards
- Active state: Primary color

## Prayer Request Form

### Fields
1. Name (required)
2. Email (required)
3. Condition (select: General, Terminal, Chronic, Mental)
4. Message (textarea, optional)

### Flow
1. Validate name + email
2. Show success state with scripture (Matthew 18:19)
3. "Submit Another Request" button

## Testimonies
- 2 text-based cards
- Hannah's Vision (macular degeneration)
- Michael's Back Pain (spinal stenosis)

## Healing School Info
- Description text
- "Watch Archives" CTA
- Wednesday 1 PM MT schedule

## Phone Ministry
- 24/7 availability
- Phone number: 719-635-1111
- "Call Now" CTA
