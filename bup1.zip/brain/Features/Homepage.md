---
type: feature
route: /
tags: [homepage, feature]
---

# Homepage

## Sections (Top to Bottom)

### 1. Hero Section
- Full-width background image
- Overlay gradient (dark)
- "Andrew Wommack Ministries" badge
- Headline: "Grace & Truth for a Changing World"
- Subtext: Mission statement
- Two CTAs: "Watch Broadcast" (primary) + "Listen Now" (outline)

### 2. Through the Bible
- Section label: "Watch a Verse By Verse Exploration"
- Title: "Through the Bible with Andrew Wommack"
- CTA: "Watch Latest Episode"
- Background: Light gradient

### 3. Quick Links Bar
- Horizontal row of 4 links:
  - Browse Teachings →
  - Audio Teachings →
  - Healing Center →
  - Español →

### 4. Resources Carousel
- Horizontal scrollable slider
- 10+ cards (events, books, shows)
- Auto-play with manual navigation
- Each card: image + title + CTA

### 5. Featured Testimony
- Two-column layout
- Left: Testimony image (circle crop)
- Right: Testimony text + "Read More" CTA
- Rotates through testimonies

### 6. Content Blocks (2x2 grid)
- **Watch**: "Enjoy the video resource page..." + CTA
- **Listen**: "Wealth of Andrew's materials..." + CTA
- **Read**: "Feed your faith with daily devotions..." + CTA
- **Internet TV**: "GTNTV.com internet TV channel..." + CTA

### 7. Video Stories
- Embedded video player
- Current featured testimony video
- Play button overlay

### 8. Donation CTA
- Full-width dark background
- Scripture: Psalms 46:1-2
- "You Can Help Others Thrive Too"
- "Donate" button (primary)

### 9. Ministries Grid
- 5 cards in responsive grid:
  - Charis Bible College
  - Truth & Liberty Coalition
  - Gospel Truth Network
  - ARMI
  - Construction Updates
- Each: image + title + description + CTA
