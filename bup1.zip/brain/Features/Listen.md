---
type: feature
route: /listen
tags: [listen, audio, feature]
---

# Listen — Audio Library

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Audio Teachings Library"          │
├─────────────────────────────────────────────┤
│  Search & Filter Bar (glass panel)          │
│  - Search input (by title/description)      │
│  - Category dropdown                        │
├─────────────────────────────────────────────┤
│  Track List                                 │
│  ┌───────────────────────────────────────┐  │
│  │ [▶] Category Badge                    │  │
│  │     Title                             │  │
│  │     Description                       │  │
│  │                        Duration       │  │
│  │                        [Listen]       │  │
│  └───────────────────────────────────────┘  │
│  ... (8 tracks)                             │
└─────────────────────────────────────────────┘
```

## Track Data

```typescript
interface Track {
  id: string;
  title: string;
  speaker: string;
  url: string;           // Audio URL
  coverUrl: string;      // Image URL
  duration: string;      // "42:18"
  category: string;
  description: string;
  year: string;
}
```

## Sample Tracks (8)

| Title | Category | Duration |
|-------|----------|----------|
| Spirit, Soul & Body: Part 1 | Spirit, Soul & Body | 42:18 |
| Spirit, Soul & Body: Part 2 | Spirit, Soul & Body | 45:30 |
| Believer's Authority: Part 1 | Believer's Authority | 38:10 |
| Believer's Authority: Part 2 | Believer's Authority | 40:15 |
| You've Already Got It: Part 1 | You've Already Got It | 44:50 |
| You've Already Got It: Part 2 | You've Already Got It | 43:10 |
| A Better Way to Pray: Part 1 | Prayer & Communion | 37:40 |
| A Better Way to Pray: Part 2 | Prayer & Communion | 39:55 |

## Audio Player (inline per-page)

### Features
- Play/Pause button per track
- Active track highlighting
- Progress indicator (if playing)
- Volume controlled by browser

### States
- Default: Blue gradient button
- Playing: Amber gradient + pause icon
- Active (current): Highlighted border + background

## Search & Filter
- Text search: matches title + description
- Category dropdown: "All" + unique categories
- Real-time filtering (no page reload)
