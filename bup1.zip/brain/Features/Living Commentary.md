---
type: feature
route: /living-commentary
tags: [living-commentary, feature]
---

# Living Commentary

> **Status**: Simplified search tool (not full 28k note database)

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Andrew's Living Commentary"       │
├─────────────────────────────────────────────┤
│  Product Overview                           │
│  - "5 decades of study notes"               │
│  - "28,000+ notes"                          │
│  - Feature highlights                       │
├─────────────────────────────────────────────┤
│  Search Tool                                │
│  ┌───────────────────────────────────────┐  │
│  │ [Search verse...]        [Search Note]│  │
│  └───────────────────────────────────────┘  │
├─────────────────────────────────────────────┤
│  Result Card (if found)                     │
│  - Reference                                │
│  - Verse text                               │
│  - Greek word study                         │
│  - Andrew's note                            │
└─────────────────────────────────────────────┘
```

## Commentary Data

```typescript
interface CommentaryNote {
  reference: string;
  verse: string;
  greekNote?: string;
  note: string;
}
```

## Sample Entries (3)

| Reference | Greek Word | Key Insight |
|-----------|------------|-------------|
| John 3:16 | agapao | Divine, self-sacrificing love |
| Romans 8:1 | katakrima | Judicial sentence abolished |
| Galatians 2:20 | systauroo | Jointly crucified with Christ |

## Search Logic
- Case-insensitive
- Loose matching (query contains key or key contains query)
- Show "No results" if not found
- "Try John 3:16 or Romans 8:1" hint
