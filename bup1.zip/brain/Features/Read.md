---
type: feature
route: /read
tags: [read, devotional, commentary, feature]
---

# Read — Daily Devotional & Commentary

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Daily Devotional & Commentary"    │
├────────────────────┬────────────────────────┤
│  Calendar Picker   │  Devotional Card        │
│  - Month/Year      │  - Date + scripture     │
│  - Weekday headers │  - Title                │
│  - Day grid (7x5)  │  - Verse block (italic) │
│  - Selected state  │  - Commentary           │
│  - Jump to today   │  - Prayer block         │
├────────────────────┴────────────────────────┤
│  Living Commentary Search Tool              │
│  - Search input + button                    │
│  - Result card (if found)                   │
└─────────────────────────────────────────────┘
```

## Calendar Picker Specs

### Month Grid
- 7 columns (Sun-Sat)
- 5 rows (31 days + offset)
- Selected day: Primary color background
- Hover state: Secondary background
- Click to select → updates devotional

### View Transition
- Use `document.startViewTransition()` for smooth swap
- Fallback for unsupported browsers

## Devotional Data

```typescript
interface Devotional {
  date: string;          // "2026-05-22"
  title: string;
  scripture: string;     // "Romans 5:8"
  verseText: string;     // Full verse quote
  commentary: string;    // Andrew's commentary
  prayer: string;        // Prayer of declaration
}
```

## Sample Devotionals (4 + fallback)

| Date | Title | Scripture |
|------|-------|-----------|
| 2026-05-22 | Unconditional Love Manifested | Romans 5:8 |
| 2026-05-23 | Already Provided | 1 Peter 2:24 |
| 2026-05-24 | Renewing the Mirror | Romans 12:2 |
| 2026-05-25 | Righteousness is a Gift | 2 Corinthians 5:21 |

### Fallback Generator
- Days without specific devotionals use generated content
- "Grace Foundations: Day X" with Galatians 2:20

## Living Commentary Search

### Commentary Database (3 entries)

| Reference | Greek Word | Key Insight |
|-----------|------------|-------------|
| John 3:16 | agapao | Divine, self-sacrificing love |
| Romans 8:1 | katakrima | Judicial sentence abolished |
| Galatians 2:20 | systauroo | Jointly crucified with Christ |

### Search Logic
- Case-insensitive
- Loose matching (query contains key or key contains query)
- Show "No results" if not found
