---
type: feature
route: /watch
tags: [watch, video, feature]
---

# Watch — Media Hub

## Layout

```
┌─────────────────────────────────────────────┐
│  Header: "Broadcasting Center"              │
├──────────────────────────┬──────────────────┤
│                          │  Sidebar          │
│   Custom Video Player    │  - Schedule info  │
│   - 16:9 aspect ratio   │  - TV air times   │
│   - Custom overlay      │  - Event dates    │
│   - Controls:           │  - External link  │
│     Play/Pause          │                   │
│     Progress bar        │                   │
│     Volume              │                   │
│     Fullscreen          │                   │
│     Time display        │                   │
├──────────────────────────┴──────────────────┤
│  Episode Description                        │
│  (Category badge, title, air date, desc)    │
├─────────────────────────────────────────────┤
│  Category Tabs: All | TV | Healing | Events │
├─────────────────────────────────────────────┤
│  Episode Grid (3 columns)                   │
│  ┌─────┐ ┌─────┐ ┌─────┐                   │
│  │ Thumb│ │ Thumb│ │ Thumb│                  │
│  │ Title│ │ Title│ │ Title│                  │
│  └─────┘ └─────┘ └─────┘                   │
└─────────────────────────────────────────────┘
```

## Video Player Specs

### Controls (always visible)
- Play/Pause button (center + bottom-left)
- Progress scrubber (range input)
- Time counter: `00:00 / 42:18`
- Volume slider + mute toggle
- Fullscreen toggle

### Custom Styling
- Gradient overlay at bottom
- White controls on dark background
- Accent color on progress bar
- Rounded corners on player container

### Error Handling
- Error overlay with icon + message
- "Retry Loading" button

## Episode Data

```typescript
interface Episode {
  id: string;
  title: string;
  category: 'tv' | 'healing' | 'destiny' | 'events';
  duration: string;
  url: string;          // Video URL
  thumbnail: string;    // Image URL
  description: string;
  airDate: string;
}
```

## Sample Episodes (6)

| Title | Category | Duration |
|-------|----------|----------|
| God's Will is Healing (Part 1) | tv | 28:15 |
| Lance's Restoration from Liver Failure | healing | 15:40 |
| Anchored in Woodland Mountains | destiny | 22:10 |
| Truth & Liberty Coalition | events | 45:30 |
| Power of Unconditional Grace | tv | 27:50 |
| Hannah's Eyesight Restored | healing | 18:25 |

## Category Filtering
- Tabs with active state
- Smooth transition on filter change
- "All" shows everything
