---
type: note
tags: [awmi, inventory]
---

# AWMI Feature Inventory

## Summary
- **Total features identified**: 116
- **Included in v1**: ~60
- **Excluded**: ~56

## Feature Count by Category

| Category | Total | Included | Excluded |
|----------|-------|----------|----------|
| Global | 12 | 5 | 7 |
| Homepage | 10 | 10 | 0 |
| Watch | 16 | 8 | 8 |
| Listen | 12 | 8 | 4 |
| Read | 12 | 8 | 4 |
| Healing | 12 | 10 | 2 |
| Give | 7 | 7 | 0 |
| Events | 4 | 0 | 4 |
| Resources | 7 | 0 | 7 |
| About | 10 | 5 | 5 |
| Store | 12 | 0 | 12 |
| Living Commentary | 12 | 3 | 9 |

## Key Differences from Real AWMI

| Aspect | AWMI Real | Our Clone |
|--------|-----------|-----------|
| Platform | WordPress | Next.js 16 |
| CMS | Headless WP | Static MDX |
| Payments | Real integration | Visual only |
| Auth | Full system | None |
| Store | Full e-commerce | External link |
| Events | Full calendar | v2 |
| Multi-language | Spanish | v1 only |
| Podcasts | 8 platforms | Links only |
| Living Commentary | 28k notes | 3 sample entries |
