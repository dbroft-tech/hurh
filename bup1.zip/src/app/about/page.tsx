"use client";

import { ArrowRight, ExternalLink, Heart, BookOpen, Users, Globe } from "lucide-react";
import { MINISTRIES } from "@/data/index";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-navy py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            About Andrew Wommack
          </h1>
          <p className="text-white/70 max-w-2xl mx-auto">
            For over 50 years, Andrew has taught the truth of God&apos;s Word
            with clarity and boldness, impacting millions worldwide.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12 space-y-16">
        {/* Bio */}
        <section>
          <div className="bg-white rounded-2xl p-8 md:p-12 shadow-sm">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-navy rounded-full flex items-center justify-center">
                <span className="text-white font-serif text-2xl font-bold">AW</span>
              </div>
              <div>
                <h2 className="font-serif text-2xl text-navy">Andrew Wommack</h2>
                <p className="text-text-light">Minister, Author, Educator</p>
              </div>
            </div>
            <div className="space-y-4 text-text leading-relaxed">
              <p>
                Andrew Wommack has been teaching God&apos;s Word since 1969. His
                unique approach to the Scriptures combines in-depth study with
                practical application, helping people understand God&apos;s
                unconditional love and grace.
              </p>
              <p>
                His daily television program, <em>Gospel Truth</em>, reaches
                millions of viewers across the world through major networks and
                the internet. His teachings are also available in over 20
                languages through his free resources.
              </p>
              <p>
                Andrew is the founder of Charis Bible College, Truth &amp;
                Liberty Coalition, and several other ministries. He and his wife,
                Jamie, have been married since 1972 and have two sons, Joshua and
                Jonathan.
              </p>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: <Globe className="w-6 h-6" />, number: "50+", label: "Years of Ministry" },
              { icon: <Users className="w-6 h-6" />, number: "Millions", label: "People Reached" },
              { icon: <BookOpen className="w-6 h-6" />, number: "20+", label: "Languages" },
              { icon: <Heart className="w-6 h-6" />, number: "100K+", label: "Partners Worldwide" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-white rounded-xl p-6 text-center shadow-sm"
              >
                <div className="w-12 h-12 bg-red/10 rounded-full flex items-center justify-center text-red mx-auto mb-3">
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold text-navy">{stat.number}</div>
                <div className="text-sm text-text-light mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Mission */}
        <section className="bg-navy rounded-2xl p-8 md:p-12 text-white">
          <h2 className="text-2xl font-serif mb-6 text-center">Our Mission</h2>
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <p className="text-white/80 text-lg italic">
              &ldquo;To present the Word of God with such clarity that people can
              easily understand and apply it to their lives.&rdquo;
            </p>
            <p className="text-white/60">
              We believe that God&apos;s Word is the final authority on every
              subject. Through teaching, media, and education, we aim to
              establish people in God&apos;s grace and help them fulfill their
              God-given destiny.
            </p>
          </div>
        </section>

        {/* Ministries */}
        <section>
          <h2 className="text-2xl font-serif text-navy mb-8 text-center">
            Our Ministries
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {MINISTRIES.map((m) => (
              <a
                key={m.name}
                href={m.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-navy/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-red/10 transition-colors">
                    <ExternalLink className="w-5 h-5 text-navy group-hover:text-red" />
                  </div>
                  <div>
                    <h3 className="font-bold text-navy group-hover:text-red transition-colors mb-1">
                      {m.name}
                    </h3>
                    <p className="text-sm text-text-light">{m.description}</p>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* Family */}
        <section className="bg-white rounded-2xl p-8 md:p-12 shadow-sm">
          <h2 className="text-2xl font-serif text-navy mb-6 text-center">
            Family &amp; Personal
          </h2>
          <div className="max-w-2xl mx-auto text-center text-text space-y-4">
            <p>
              Andrew and Jamie Wommack have been married since 1972. They have
              two sons, Joshua and Jonathan, both of whom serve in various
              capacities within the ministry.
            </p>
            <p>
              Andrew&apos;s passion for God&apos;s Word has taken him to over
              40 countries, where he has ministered to hundreds of thousands
              of people through crusades, conferences, and church services.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
