"use client";

import { useState } from "react";
import { Search, Play, Headphones, BookOpen, Filter, ChevronDown } from "lucide-react";
import { TOPICS } from "@/data/index";
import { EPISODES } from "@/data/episodes";
import { TRACKS } from "@/data/tracks";

type ContentItem = {
  id: string;
  title: string;
  type: "video" | "audio" | "article";
  category: string;
  description: string;
  duration?: string;
};

const ALL_ITEMS: ContentItem[] = [
  ...EPISODES.map((ep) => ({
    id: ep.id,
    title: ep.title,
    type: "video" as const,
    category: ep.category,
    description: ep.description,
    duration: ep.duration,
  })),
  ...TRACKS.map((t) => ({
    id: t.id,
    title: t.title,
    type: "audio" as const,
    category: t.category,
    description: t.description,
    duration: t.duration,
  })),
];

export default function BrowsePage() {
  const [query, setQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedTopic, setSelectedTopic] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = ALL_ITEMS.filter((item) => {
    const matchesQuery = query
      ? item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase())
      : true;
    const matchesType = selectedType === "all" || item.type === selectedType;
    const matchesTopic =
      selectedTopic === "all" ||
      item.category.toLowerCase().includes(selectedTopic.toLowerCase());
    return matchesQuery && matchesType && matchesTopic;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Play className="w-4 h-4" />;
      case "audio":
        return <Headphones className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-navy py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            Browse Teachings
          </h1>
          <p className="text-white/70 max-w-2xl mx-auto">
            Explore hundreds of free teachings on faith, healing, grace, and
            victorious living.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Search + Filters */}
        <div className="bg-white rounded-xl p-6 shadow-sm mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-light" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search teachings by title or keyword..."
                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 bg-cream hover:bg-navy/5 px-4 py-3 rounded-lg text-sm font-medium text-navy transition-colors"
            >
              <Filter className="w-4 h-4" />
              Filters
              <ChevronDown
                className={`w-4 h-4 transition-transform ${
                  showFilters ? "rotate-180" : ""
                }`}
              />
            </button>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-100 grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-navy mb-2">
                  Content Type
                </label>
                <div className="flex flex-wrap gap-2">
                  {["all", "video", "audio"].map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                        selectedType === type
                          ? "bg-red text-white"
                          : "bg-cream text-navy hover:bg-navy/10"
                      }`}
                    >
                      {type === "all" ? "All" : type.charAt(0).toUpperCase() + type.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-navy mb-2">
                  Topic
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedTopic("all")}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedTopic === "all"
                        ? "bg-red text-white"
                        : "bg-cream text-navy hover:bg-navy/10"
                    }`}
                  >
                    All Topics
                  </button>
                  {TOPICS.slice(0, 6).map((topic) => (
                    <button
                      key={topic.name}
                      onClick={() => setSelectedTopic(topic.name)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                        selectedTopic === topic.name
                          ? "bg-red text-white"
                          : "bg-cream text-navy hover:bg-navy/10"
                      }`}
                    >
                      {topic.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-text-light text-sm">
            Showing <strong>{filtered.length}</strong> results
          </p>
        </div>

        {/* Results Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl">
            <Search className="w-12 h-12 text-text-light/30 mx-auto mb-4" />
            <p className="text-text-light mb-2">No teachings found</p>
            <p className="text-sm text-text-light/60">
              Try adjusting your search or filters
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((item) => (
              <a
                key={item.id}
                href={item.type === "video" ? "/watch" : "/listen"}
                className="group bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition-all"
              >
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <span
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        item.type === "video"
                          ? "bg-red/10 text-red"
                          : "bg-navy/10 text-navy"
                      }`}
                    >
                      {getIcon(item.type)}
                    </span>
                    <span className="text-xs font-medium text-text-light uppercase">
                      {item.type}
                    </span>
                    {item.duration && (
                      <span className="text-xs text-text-light/60 ml-auto">
                        {item.duration}
                      </span>
                    )}
                  </div>
                  <h3 className="font-semibold text-dark group-hover:text-red transition-colors mb-2 line-clamp-2">
                    {item.title}
                  </h3>
                  <p className="text-sm text-text-light line-clamp-2">
                    {item.description}
                  </p>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
