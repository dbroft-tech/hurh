"use client";

import { useState } from "react";
import { Heart, Calculator, DollarSign, CheckCircle, ChevronDown, ArrowRight } from "lucide-react";
import { TIERS } from "@/data/index";

const GIVE_AMOUNTS = [25, 50, 100, 250, 500, 1000];

export default function GivePage() {
  const [amount, setAmount] = useState(100);
  const [customAmount, setCustomAmount] = useState("");
  const [frequency, setFrequency] = useState<"one-time" | "monthly">("one-time");
  const [showCalculator, setShowCalculator] = useState(false);
  const [monthlyIncome, setMonthlyIncome] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [selectedTier, setSelectedTier] = useState(
    TIERS.find((t) => amount >= t.minAmount && amount <= t.maxAmount) || TIERS[0]
  );

  const handleAmountSelect = (value: number) => {
    setAmount(value);
    setCustomAmount("");
    const tier = TIERS.find((t) => value >= t.minAmount && value <= t.maxAmount);
    if (tier) setSelectedTier(tier);
  };

  const handleCustomAmount = (value: string) => {
    setCustomAmount(value);
    const num = parseInt(value);
    if (!isNaN(num) && num > 0) {
      setAmount(num);
      const tier = TIERS.find((t) => num >= t.minAmount && num <= t.maxAmount);
      if (tier) setSelectedTier(tier);
    }
  };

  const calculatePercentage = () => {
    const income = parseFloat(monthlyIncome);
    if (isNaN(income) || income <= 0) return null;
    const tithe = income * 0.1;
    const percent = (amount / tithe) * 100;
    return { tithe, percent: Math.min(percent, 100) };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-gradient-to-br from-red to-red-dark py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <Heart className="w-12 h-12 text-white mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            Give Today
          </h1>
          <p className="text-white/80 max-w-2xl mx-auto">
            Your generous gifts help spread the Gospel worldwide. Every donation
            supports free teachings, healing journeys, and mission outreaches.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Donation Form */}
          <div className="lg:col-span-2">
            {submitted ? (
              <div className="bg-white rounded-2xl p-12 shadow-sm text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-serif text-navy mb-4">
                  Thank You for Your Gift!
                </h2>
                <p className="text-text-light mb-6">
                  Your {frequency === "monthly" ? "monthly" : "one-time"} gift of{" "}
                  <strong>${amount}</strong> will help spread the Gospel around the world.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="text-red hover:text-red-dark font-semibold transition-colors"
                >
                  Make Another Gift
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                {/* Frequency Toggle */}
                <div className="flex bg-cream rounded-lg p-1 mb-8">
                  {(["one-time", "monthly"] as const).map((freq) => (
                    <button
                      key={freq}
                      onClick={() => setFrequency(freq)}
                      className={`flex-1 py-3 rounded-md text-sm font-semibold transition-colors ${
                        frequency === freq
                          ? "bg-white text-navy shadow-sm"
                          : "text-text-light hover:text-navy"
                      }`}
                    >
                      {freq === "one-time" ? "One-Time Gift" : "Monthly Partner"}
                    </button>
                  ))}
                </div>

                {/* Amount Selection */}
                <h3 className="font-semibold text-navy mb-4">Select Amount</h3>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {GIVE_AMOUNTS.map((value) => (
                    <button
                      key={value}
                      onClick={() => handleAmountSelect(value)}
                      className={`py-3 rounded-lg font-semibold transition-all ${
                        amount === value && !customAmount
                          ? "bg-red text-white shadow-md"
                          : "bg-cream text-navy hover:bg-navy/10"
                      }`}
                    >
                      ${value}
                    </button>
                  ))}
                </div>
                <div className="relative mb-6">
                  <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-light" />
                  <input
                    type="number"
                    min="1"
                    placeholder="Custom amount"
                    value={customAmount}
                    onChange={(e) => handleCustomAmount(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-lg text-lg font-semibold focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                  />
                </div>

                {/* Calculator Toggle */}
                <button
                  onClick={() => setShowCalculator(!showCalculator)}
                  className="flex items-center gap-2 text-sm text-navy hover:text-red transition-colors mb-6"
                >
                  <Calculator className="w-4 h-4" />
                  {showCalculator ? "Hide" : "Show"} Tithe Calculator
                </button>

                {showCalculator && (
                  <div className="bg-cream rounded-lg p-4 mb-6">
                    <label className="block text-sm font-medium text-navy mb-2">
                      Monthly Income
                    </label>
                    <div className="relative mb-3">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-light" />
                      <input
                        type="number"
                        placeholder="e.g., 5000"
                        value={monthlyIncome}
                        onChange={(e) => setMonthlyIncome(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                      />
                    </div>
                    {calculatePercentage() && (
                      <div className="text-sm text-text-light">
                        <p>
                          10% Tithe: <strong>${calculatePercentage()!.tithe.toFixed(2)}</strong>
                        </p>
                        <div className="mt-2 h-2 bg-white rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red rounded-full transition-all"
                            style={{ width: `${calculatePercentage()!.percent}%` }}
                          />
                        </div>
                        <p className="mt-1">
                          Your gift is{" "}
                          <strong>{calculatePercentage()!.percent.toFixed(0)}%</strong> of
                          tithe
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Form Fields */}
                <div className="space-y-4 mb-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      required
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      required
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy mb-1">
                        Expiry
                      </label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        required
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy mb-1">
                        CVV
                      </label>
                      <input
                        type="text"
                        placeholder="123"
                        required
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  className="w-full flex items-center justify-center gap-2 bg-red hover:bg-red-dark text-white py-4 rounded-full font-bold text-lg transition-colors"
                >
                  <Heart className="w-5 h-5" />
                  Give ${amount} {frequency === "monthly" ? "Monthly" : "Now"}
                </button>
              </div>
            )}
          </div>

          {/* Partnership Tiers */}
          <div className="space-y-4">
            <h3 className="font-serif font-bold text-navy text-lg">
              Partnership Levels
            </h3>
            {TIERS.map((tier) => (
              <div
                key={tier.name}
                className={`bg-white rounded-xl p-5 shadow-sm border-2 transition-all cursor-pointer ${
                  selectedTier.name === tier.name
                    ? "border-red"
                    : "border-transparent hover:border-gray-200"
                }`}
                onClick={() => {
                  setAmount(tier.minAmount);
                  setCustomAmount("");
                  setSelectedTier(tier);
                }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-gold/20 rounded-full flex items-center justify-center">
                    <Heart className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <div className="font-bold text-navy">{tier.name}</div>
                    <div className="text-xs text-text-light">
                      ${tier.minAmount} – ${tier.maxAmount}/mo
                    </div>
                  </div>
                </div>
                <p className="text-xs text-gold font-semibold mb-2">
                  Badge: {tier.badge}
                </p>
                <ul className="space-y-1.5">
                  {tier.benefits.map((b, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-text-light">
                      <ArrowRight className="w-3 h-3 mt-1 shrink-0 text-gold" />
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
