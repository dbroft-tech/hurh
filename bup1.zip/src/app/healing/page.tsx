"use client";

import { useState } from "react";
import { Heart, Play, BookOpen, Send, CheckCircle, ChevronDown } from "lucide-react";
import { HEALING_SCRIPTURES } from "@/data/index";
import { EPISODES } from "@/data/episodes";

const CATEGORIES = ["general", "terminal", "chronic", "mental"] as const;
const CATEGORY_LABELS: Record<string, string> = {
  general: "General Healing",
  terminal: "Serious Illness",
  chronic: "Chronic Conditions",
  mental: "Mental Health",
};

export default function HealingPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("general");
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    condition: "",
    details: "",
  });

  const filteredScriptures = HEALING_SCRIPTURES.filter(
    (s) => s.category === selectedCategory
  );

  const healingEpisodes = EPISODES.filter((ep) => ep.category === "healing");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setShowForm(false);
      setFormData({ name: "", email: "", condition: "", details: "" });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-gradient-to-br from-red to-red-dark py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <Heart className="w-12 h-12 text-white mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            Healing Center
          </h1>
          <p className="text-white/80 max-w-2xl mx-auto">
            By the stripes of Jesus, you were healed. Stand on God&apos;s Word
            and receive your healing today.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Scripture Declarations */}
        <section className="mb-16">
          <h2 className="text-2xl font-serif text-navy mb-6">
            Healing Scripture Declarations
          </h2>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === cat
                    ? "bg-red text-white"
                    : "bg-white text-navy hover:bg-navy/5 border border-gray-200"
                }`}
              >
                {CATEGORY_LABELS[cat]}
              </button>
            ))}
          </div>

          {/* Scriptures */}
          <div className="space-y-4">
            {filteredScriptures.map((scripture) => (
              <div
                key={scripture.reference}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
              >
                <h3 className="font-serif font-bold text-navy text-lg mb-2">
                  {scripture.reference}
                </h3>
                <blockquote className="text-text italic border-l-4 border-gold pl-4 py-2 bg-cream/50 mb-4">
                  {scripture.verse}
                </blockquote>
                <div className="bg-navy/5 rounded-lg p-4">
                  <p className="font-medium text-navy">
                    🙏 {scripture.declaration}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Healing Videos */}
        <section className="mb-16">
          <h2 className="text-2xl font-serif text-navy mb-6">
            Healing Journey Testimonies
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {healingEpisodes.map((ep) => (
              <a
                key={ep.id}
                href="/watch"
                className="group bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg transition-all"
              >
                <div className="relative aspect-video bg-gradient-to-br from-red/20 to-navy flex items-center justify-center">
                  <div className="w-14 h-14 bg-red/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Play className="w-6 h-6 text-white ml-0.5" />
                  </div>
                  <span className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                    {ep.duration}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-dark group-hover:text-red transition-colors mb-2">
                    {ep.title}
                  </h3>
                  <p className="text-sm text-text-light line-clamp-2">
                    {ep.description}
                  </p>
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* Prayer Request */}
        <section className="bg-white rounded-2xl p-8 md:p-12 shadow-sm border border-gray-100">
          <div className="max-w-2xl mx-auto text-center">
            <Heart className="w-10 h-10 text-red mx-auto mb-4" />
            <h2 className="text-2xl font-serif text-navy mb-4">
              Submit a Prayer Request
            </h2>
            <p className="text-text-light mb-8">
              Our prayer team stands with you in faith. Share your request and
              we will pray with you.
            </p>

            {!showForm && !submitted && (
              <button
                onClick={() => setShowForm(true)}
                className="bg-red hover:bg-red-dark text-white px-8 py-3 rounded-full font-semibold transition-colors"
              >
                Submit Prayer Request
              </button>
            )}

            {submitted && (
              <div className="flex items-center justify-center gap-3 text-green-600">
                <CheckCircle className="w-6 h-6" />
                <span className="font-semibold">Request submitted. We are praying with you!</span>
              </div>
            )}

            {showForm && !submitted && (
              <form onSubmit={handleSubmit} className="text-left space-y-4 mt-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-navy mb-1">Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy mb-1">Condition</label>
                  <input
                    type="text"
                    placeholder="e.g., Back pain, Cancer, Anxiety..."
                    value={formData.condition}
                    onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy mb-1">
                    Additional Details (optional)
                  </label>
                  <textarea
                    rows={4}
                    value={formData.details}
                    onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy resize-none"
                  />
                </div>
                <div className="flex gap-4 pt-2">
                  <button
                    type="submit"
                    className="flex items-center gap-2 bg-red hover:bg-red-dark text-white px-8 py-3 rounded-full font-semibold transition-colors"
                  >
                    <Send className="w-4 h-4" /> Submit Request
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-6 py-3 rounded-full text-navy hover:bg-cream transition-colors font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
