"use client";

import { useState, useRef, useEffect } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Search, ChevronDown } from "lucide-react";
import { TRACKS, Track } from "@/data/tracks";

const CATEGORIES = ["All", "Spirit, Soul & Body", "Believer's Authority", "You've Already Got It", "Prayer & Communion"] as const;

export default function ListenPage() {
  const [currentTrack, setCurrentTrack] = useState<Track>(TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState("0:00");
  const [category, setCategory] = useState<string>("All");
  const [showDropdown, setShowDropdown] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const filtered = category === "All"
    ? TRACKS
    : TRACKS.filter((t) => t.category === category);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const updateProgress = () => {
      if (audio.duration) {
        setProgress((audio.currentTime / audio.duration) * 100);
        const mins = Math.floor(audio.currentTime / 60);
        const secs = Math.floor(audio.currentTime % 60);
        setCurrentTime(`${mins}:${secs.toString().padStart(2, "0")}`);
      }
    };
    audio.addEventListener("timeupdate", updateProgress);
    audio.addEventListener("ended", () => handleNext());
    return () => {
      audio.removeEventListener("timeupdate", updateProgress);
      audio.removeEventListener("ended", () => handleNext());
    };
  }, [currentTrack]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    isPlaying ? audioRef.current.pause() : audioRef.current.play();
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!audioRef.current) return;
    const time = (parseFloat(e.target.value) / 100) * audioRef.current.duration;
    audioRef.current.currentTime = time;
    setProgress(parseFloat(e.target.value));
  };

  const handleNext = () => {
    const idx = filtered.findIndex((t) => t.id === currentTrack.id);
    const next = filtered[(idx + 1) % filtered.length];
    setCurrentTrack(next);
    setIsPlaying(false);
    setProgress(0);
  };

  const handlePrev = () => {
    const idx = filtered.findIndex((t) => t.id === currentTrack.id);
    const prev = filtered[(idx - 1 + filtered.length) % filtered.length];
    setCurrentTrack(prev);
    setIsPlaying(false);
    setProgress(0);
  };

  return (
    <div className="min-h-screen bg-dark">
      {/* Player */}
      <div className="bg-gradient-to-b from-navy-dark to-dark py-12">
        <div className="max-w-4xl mx-auto px-4">
          <audio ref={audioRef} key={currentTrack.id}>
            <source src={currentTrack.url} type="audio/mpeg" />
          </audio>

          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Cover */}
            <div className="w-48 h-48 md:w-56 md:h-56 rounded-2xl bg-navy/50 overflow-hidden shadow-2xl shrink-0">
              <div className="w-full h-full bg-gradient-to-br from-red/30 to-navy flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl mb-2">🎧</div>
                  <div className="text-xs text-white/50">Now Playing</div>
                </div>
              </div>
            </div>

            {/* Info + Controls */}
            <div className="flex-1 text-center md:text-left">
              <div className="text-xs text-gold font-medium uppercase tracking-wider mb-2">
                {currentTrack.category}
              </div>
              <h1 className="text-2xl md:text-3xl font-serif text-white mb-2 line-clamp-2">
                {currentTrack.title}
              </h1>
              <p className="text-white/60 mb-6">{currentTrack.speaker}</p>

              {/* Progress */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-xs text-white/50 w-10 text-right">{currentTime}</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={progress}
                  onChange={handleSeek}
                  className="flex-1 h-1 accent-red cursor-pointer"
                />
                <span className="text-xs text-white/50 w-10">{currentTrack.duration}</span>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center md:justify-start gap-4">
                <button
                  onClick={handlePrev}
                  className="text-white/60 hover:text-white transition-colors"
                >
                  <SkipBack className="w-6 h-6" />
                </button>
                <button
                  onClick={togglePlay}
                  className="w-14 h-14 bg-red hover:bg-red-dark rounded-full flex items-center justify-center transition-colors"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white ml-0.5" />
                  )}
                </button>
                <button
                  onClick={handleNext}
                  className="text-white/60 hover:text-white transition-colors"
                >
                  <SkipForward className="w-6 h-6" />
                </button>
                <button
                  onClick={() => {
                    if (audioRef.current) audioRef.current.muted = !isMuted;
                    setIsMuted(!isMuted);
                  }}
                  className="text-white/60 hover:text-white transition-colors ml-4"
                >
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Track List */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-serif text-white">Teaching Library</h2>
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="flex items-center gap-2 bg-white/10 text-white px-4 py-2 rounded-lg text-sm"
            >
              {category} <ChevronDown className="w-4 h-4" />
            </button>
            {showDropdown && (
              <div className="absolute top-full right-0 bg-dark border border-white/10 rounded-lg mt-1 z-10 min-w-[200px]">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setCategory(cat);
                      setShowDropdown(false);
                    }}
                    className={`w-full text-left px-4 py-2.5 text-sm hover:bg-white/10 transition-colors ${
                      category === cat ? "text-gold" : "text-white"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          {filtered.map((track) => (
            <button
              key={track.id}
              onClick={() => {
                setCurrentTrack(track);
                setIsPlaying(false);
                setProgress(0);
              }}
              className={`w-full flex items-center gap-4 p-4 rounded-xl text-left transition-all ${
                currentTrack.id === track.id
                  ? "bg-red/20 border border-red/30"
                  : "bg-white/5 hover:bg-white/10 border border-transparent"
              }`}
            >
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${
                currentTrack.id === track.id ? "bg-red" : "bg-white/10"
              }`}>
                {currentTrack.id === track.id && isPlaying ? (
                  <Pause className="w-5 h-5 text-white" />
                ) : (
                  <Play className="w-5 h-5 text-white ml-0.5" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className={`font-medium truncate ${
                  currentTrack.id === track.id ? "text-white" : "text-white/80"
                }`}>
                  {track.title}
                </div>
                <div className="text-sm text-white/50">{track.speaker}</div>
              </div>
              <div className="text-sm text-white/50 shrink-0">{track.duration}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
