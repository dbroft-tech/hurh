"use client";

import Link from "next/link";
import {
  Play,
  Headphones,
  BookOpen,
  Heart,
  ArrowRight,
  Calendar,
  Quote,
} from "lucide-react";
import { EPISODES } from "@/data/episodes";
import { TESTIMONIALS, MINISTRIES, TOPICS } from "@/data/index";
import { DEVOTIONALS } from "@/data/devotionals";
import { useEffect, useState } from "react";

export default function HomePage() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [featuredVideo] = useState(EPISODES[0]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const today = new Date().toISOString().split("T")[0];
  const devotional = DEVOTIONALS[today] || {
    title: "Grace & Faith Today",
    scripture: "Galatians 2:20",
    verseText: '"I am crucified with Christ: nevertheless I live; yet not I, but Christ liveth in me."',
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative bg-navy">
        <div className="absolute inset-0 bg-gradient-to-br from-navy via-navy-dark to-dark opacity-90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Text Content */}
            <div className="text-center lg:text-left order-2 lg:order-1">
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-gold mb-6">
                <span className="w-2 h-2 bg-gold rounded-full animate-pulse" />
                Gospel Truth TV
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif text-white leading-tight mb-6">
                God&apos;s Will Is{" "}
                <span className="text-gold">Always</span>{" "}
                Healing
              </h1>
              <p className="text-lg text-white/70 max-w-xl mb-8 mx-auto lg:mx-0">
                Join Andrew Wommack as he unlocks the truth about divine healing
                and God&apos;s unconditional love.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link
                  href="/watch"
                  className="inline-flex items-center justify-center gap-2 bg-red hover:bg-red-dark text-white px-8 py-4 rounded-full font-bold text-lg transition-colors shadow-lg"
                >
                  <Play className="w-5 h-5" /> Watch Now
                </Link>
                <Link
                  href="/read"
                  className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white px-8 py-4 rounded-full font-bold text-lg transition-colors"
                >
                  <BookOpen className="w-5 h-5" /> Read Devotional
                </Link>
              </div>
            </div>

            {/* Video Card */}
            <div className="order-1 lg:order-2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl group cursor-pointer mx-auto max-w-lg lg:max-w-none">
                <div className="aspect-video bg-gradient-to-br from-navy-dark to-dark flex items-center justify-center">
                  <div className="w-20 h-20 bg-red/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Play className="w-8 h-8 text-white ml-1" />
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 text-sm font-medium truncate pr-4">
                      {featuredVideo.title}
                    </span>
                    <span className="bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded shrink-0">
                      {featuredVideo.duration}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Access Cards */}
      <section className="relative bg-white -mt-8 z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: <Play className="w-6 h-6" />, label: "Watch", sublabel: "TV & Videos", href: "/watch", color: "bg-red" },
              { icon: <Headphones className="w-6 h-6" />, label: "Listen", sublabel: "Audio Library", href: "/listen", color: "bg-navy" },
              { icon: <BookOpen className="w-6 h-6" />, label: "Read", sublabel: "Devotionals", href: "/read", color: "bg-gold" },
              { icon: <Heart className="w-6 h-6" />, label: "Give", sublabel: "Support", href: "/give", color: "bg-red" },
            ].map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="bg-white rounded-xl border border-gray-200 p-5 text-center hover:border-navy/20 hover:shadow-lg transition-all group"
              >
                <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center text-white mx-auto mb-3 group-hover:scale-110 transition-transform`}>
                  {item.icon}
                </div>
                <div className="font-bold text-dark text-sm">{item.label}</div>
                <div className="text-xs text-text-light mt-0.5">{item.sublabel}</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Devotional Preview */}
      <section className="bg-cream py-16 mt-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-serif text-navy">Today&apos;s Devotional</h2>
              <p className="text-text-light mt-1 text-sm">Daily truth to transform your life</p>
            </div>
            <Link
              href="/read"
              className="hidden sm:flex items-center gap-2 text-red hover:text-red-dark font-semibold text-sm transition-colors"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="bg-white rounded-2xl p-6 md:p-10 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <Calendar className="w-4 h-4 text-gold" />
              <span className="text-xs font-medium text-gold">
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </div>
            <h3 className="text-xl md:text-2xl font-serif text-navy mb-2">{devotional.title}</h3>
            <p className="text-red font-semibold text-sm mb-4">{devotional.scripture}</p>
            <blockquote className="text-text italic border-l-4 border-gold pl-5 py-2 text-base md:text-lg bg-cream/50 rounded-r-lg mb-6">
              {devotional.verseText}
            </blockquote>
            <Link
              href="/read"
              className="inline-flex items-center gap-2 text-red hover:text-red-dark font-semibold text-sm transition-colors"
            >
              Read Full Devotional <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Videos */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-serif text-navy">Featured Episodes</h2>
              <p className="text-text-light mt-1 text-sm">Watch and be transformed</p>
            </div>
            <Link
              href="/watch"
              className="flex items-center gap-2 text-red hover:text-red-dark font-semibold text-sm transition-colors"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {EPISODES.slice(0, 3).map((episode) => (
              <Link
                key={episode.id}
                href="/watch"
                className="group rounded-xl overflow-hidden border border-gray-200 hover:shadow-lg transition-all"
              >
                <div className="relative aspect-video bg-gradient-to-br from-navy to-dark">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-red/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                      <Play className="w-5 h-5 text-white ml-0.5" />
                    </div>
                  </div>
                  <div className="absolute top-3 left-3">
                    <span className="bg-red text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wide">
                      {episode.category}
                    </span>
                  </div>
                  <div className="absolute bottom-3 right-3">
                    <span className="bg-black/60 backdrop-blur-sm text-white text-xs px-2 py-1 rounded">
                      {episode.duration}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-dark group-hover:text-red transition-colors mb-2 line-clamp-2 text-sm">
                    {episode.title}
                  </h3>
                  <p className="text-xs text-text-light line-clamp-2">{episode.description}</p>
                  <p className="text-[11px] text-text-light/60 mt-3">{episode.airDate}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Browse by Topic */}
      <section className="bg-navy py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-serif text-white mb-2">Browse by Topic</h2>
            <p className="text-white/60 text-sm">Find teachings on the subjects that matter most to you</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {TOPICS.map((topic) => (
              <Link
                key={topic.name}
                href="/browse"
                className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-4 text-center transition-all group"
              >
                <div className="text-2xl mb-2">{topic.icon}</div>
                <div className="font-semibold text-white text-xs group-hover:text-gold transition-colors">
                  {topic.name}
                </div>
                <div className="text-[10px] text-white/50 mt-1">{topic.count} teachings</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-cream py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-serif text-navy mb-10">Testimonies of Grace</h2>
          <div className="relative min-h-[200px]">
            {TESTIMONIALS.map((t, i) => (
              <div
                key={i}
                className={`absolute inset-0 transition-all duration-500 flex flex-col items-center justify-center ${
                  i === currentTestimonial ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
                }`}
              >
                <Quote className="w-8 h-8 text-gold mx-auto mb-4" />
                <p className="text-base md:text-lg text-dark italic mb-6 leading-relaxed">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <p className="font-semibold text-navy text-sm">
                  {t.name}, {t.location}
                </p>
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-2 mt-8">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentTestimonial(i)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  i === currentTestimonial ? "bg-red" : "bg-navy/20"
                }`}
                aria-label={`Testimonial ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Ministries */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-serif text-navy mb-2">Our Ministries</h2>
            <p className="text-text-light text-sm">Reaching the world with the Gospel</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {MINISTRIES.slice(0, 3).map((m) => (
              <a
                key={m.name}
                href={m.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group rounded-xl overflow-hidden border border-gray-200 hover:shadow-lg transition-all"
              >
                <div className="aspect-[16/9] bg-gradient-to-br from-navy to-dark flex items-center justify-center p-6">
                  <div className="text-center">
                    <h3 className="font-serif text-lg text-white mb-2 group-hover:text-gold transition-colors">{m.name}</h3>
                    <p className="text-xs text-white/70 leading-relaxed">{m.description}</p>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Healing CTA */}
      <section className="bg-red py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Heart className="w-10 h-10 text-white mx-auto mb-4" />
          <h2 className="text-2xl md:text-3xl font-serif text-white mb-4">
            Do You Need Healing?
          </h2>
          <p className="text-white/80 text-sm max-w-xl mx-auto mb-8">
            God&apos;s Word contains healing promises. Submit your prayer request
            and let us stand with you in faith.
          </p>
          <Link
            href="/healing"
            className="inline-flex items-center gap-2 bg-white text-red hover:bg-cream px-8 py-3 rounded-full font-bold transition-colors"
          >
            Healing Resources <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Free Resources */}
      <section className="bg-navy py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-serif text-white mb-2">Free Resources</h2>
            <p className="text-white/60 text-sm max-w-lg mx-auto">
              Download free teachings and devotionals to grow your faith
            </p>
          </div>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              {
                icon: <BookOpen className="w-6 h-6" />,
                title: "Free Books",
                desc: "Download Andrew's classic books in digital format",
              },
              {
                icon: <Headphones className="w-6 h-6" />,
                title: "Audio Teachings",
                desc: "Stream or download hundreds of free audio messages",
              },
              {
                icon: <Play className="w-6 h-6" />,
                title: "Video Series",
                desc: "Watch Andrew's complete teaching library online",
              },
            ].map((r) => (
              <div
                key={r.title}
                className="bg-white/5 border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-colors text-center"
              >
                <div className="w-14 h-14 bg-red rounded-full flex items-center justify-center text-white mx-auto mb-4">
                  {r.icon}
                </div>
                <h3 className="font-bold text-white text-sm mb-2">{r.title}</h3>
                <p className="text-xs text-white/60 leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
