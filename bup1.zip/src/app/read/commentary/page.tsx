"use client";

import { useState } from "react";
import { Search, BookOpen, ChevronDown } from "lucide-react";
import { COMMENTARY_DB } from "@/data/index";

export default function CommentaryPage() {
  const [query, setQuery] = useState("");
  const [selectedNote, setSelectedNote] = useState<string | null>(null);
  const [showInfo, setShowInfo] = useState(false);

  const entries = Object.values(COMMENTARY_DB);

  const filtered = query
    ? entries.filter(
        (e) =>
          e.reference.toLowerCase().includes(query.toLowerCase()) ||
          e.note.toLowerCase().includes(query.toLowerCase())
      )
    : entries;

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-navy py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <BookOpen className="w-12 h-12 text-gold mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            Living Commentary
          </h1>
          <p className="text-white/70 max-w-2xl mx-auto">
            Andrew&apos;s personal Bible study notes. Search by verse to uncover
            deeper meaning through the lens of God&apos;s grace.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Search */}
        <div className="bg-white rounded-xl p-6 shadow-sm mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-light" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder='Search by verse (e.g., "John 3:16", "Romans 8:1")...'
              className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
            />
          </div>

          <button
            onClick={() => setShowInfo(!showInfo)}
            className="flex items-center gap-2 text-sm text-navy hover:text-red mt-4 transition-colors"
          >
            <ChevronDown className={`w-4 h-4 transition-transform ${showInfo ? "rotate-180" : ""}`} />
            How to use the Living Commentary
          </button>

          {showInfo && (
            <div className="mt-4 p-4 bg-cream rounded-lg text-sm text-text-light">
              <p className="mb-2">
                The Living Commentary contains Andrew&apos;s personal study notes
                accumulated over decades of teaching God&apos;s Word.
              </p>
              <p>
                Enter a Bible reference (e.g., &quot;John 3:16&quot;) to find
                notes on that passage. Each entry includes the verse text,
                Greek/Hebrew insights, and commentary.
              </p>
            </div>
          )}
        </div>

        {/* Results */}
        <div className="space-y-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-xl">
              <BookOpen className="w-12 h-12 text-text-light/30 mx-auto mb-4" />
              <p className="text-text-light">No commentary found for &quot;{query}&quot;</p>
              <p className="text-sm text-text-light/60 mt-2">
                Try a different verse reference
              </p>
            </div>
          ) : (
            filtered.map((note) => (
              <div
                key={note.reference}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <button
                  onClick={() =>
                    setSelectedNote(selectedNote === note.reference ? null : note.reference)
                  }
                  className="w-full flex items-center justify-between p-6 text-left hover:bg-cream/50 transition-colors"
                >
                  <div>
                    <h3 className="font-serif font-bold text-navy text-lg">
                      {note.reference}
                    </h3>
                    <p className="text-sm text-text-light mt-1 line-clamp-1">
                      {note.verse}
                    </p>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-text-light shrink-0 transition-transform ${
                      selectedNote === note.reference ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {selectedNote === note.reference && (
                  <div className="px-6 pb-6 space-y-4 border-t border-gray-100 pt-4">
                    <blockquote className="text-text italic border-l-4 border-gold pl-4 py-2 bg-cream/50">
                      {note.verse}
                    </blockquote>

                    {note.greekNote && (
                      <div className="bg-navy/5 rounded-lg p-4">
                        <h4 className="font-semibold text-navy text-sm mb-2">
                          Greek/Hebrew Insight
                        </h4>
                        <p className="text-sm text-text">{note.greekNote}</p>
                      </div>
                    )}

                    <div>
                      <h4 className="font-semibold text-navy text-sm mb-2">Commentary</h4>
                      <p className="text-text">{note.note}</p>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
