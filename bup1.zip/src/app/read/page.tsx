"use client";

import { useState } from "react";
import { Calendar, ChevronLeft, ChevronRight, BookOpen } from "lucide-react";
import { DEVOTIONALS, getDevotionalForDate } from "@/data/devotionals";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function ReadPage() {
  const today = new Date();
  const [currentDate, setCurrentDate] = useState(today);
  const [showCalendar, setShowCalendar] = useState(false);

  const dateStr = currentDate.toISOString().split("T")[0];
  const devotional = getDevotionalForDate(dateStr);

  const navigateDate = (direction: number) => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() + direction);
    setCurrentDate(newDate);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <div className="bg-navy py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <BookOpen className="w-12 h-12 text-gold mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
            Daily Devotional
          </h1>
          <p className="text-white/70 max-w-2xl mx-auto">
            Begin your day with truth that transforms. Each devotional reveals
            God&apos;s unconditional love and grace.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Date Navigation */}
        <div className="flex items-center justify-between mb-8 bg-white rounded-xl p-4 shadow-sm">
          <button
            onClick={() => navigateDate(-1)}
            className="p-2 hover:bg-cream rounded-full transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-navy" />
          </button>
          <button
            onClick={() => setShowCalendar(!showCalendar)}
            className="flex items-center gap-2 font-semibold text-navy"
          >
            <Calendar className="w-5 h-5" />
            {formatDate(currentDate)}
          </button>
          <button
            onClick={() => navigateDate(1)}
            className="p-2 hover:bg-cream rounded-full transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-navy" />
          </button>
        </div>

        {/* Simple Calendar Dropdown */}
        {showCalendar && (
          <div className="bg-white rounded-xl p-4 shadow-lg mb-8 max-w-sm mx-auto">
            <div className="grid grid-cols-6 gap-2">
              {MONTHS.map((month, i) => (
                <button
                  key={month}
                  onClick={() => {
                    const d = new Date(currentDate);
                    d.setMonth(i);
                    setCurrentDate(d);
                    setShowCalendar(false);
                  }}
                  className={`py-2 rounded text-sm font-medium transition-colors ${
                    currentDate.getMonth() === i
                      ? "bg-red text-white"
                      : "bg-cream hover:bg-navy/10 text-navy"
                  }`}
                >
                  {month}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Devotional Content */}
        <article className="bg-white rounded-2xl p-8 md:p-12 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <span className="bg-gold/20 text-gold-dark px-3 py-1 rounded-full text-sm font-medium">
              {devotional.scripture}
            </span>
          </div>

          <h2 className="text-2xl md:text-3xl font-serif text-navy mb-6">
            {devotional.title}
          </h2>

          <blockquote className="text-lg italic border-l-4 border-gold pl-6 py-3 bg-cream/50 rounded-r-lg mb-8">
            {devotional.verseText}
          </blockquote>

          <div className="prose max-w-none text-text leading-relaxed mb-8">
            <p className="text-lg">{devotional.commentary}</p>
          </div>

          {/* Prayer */}
          <div className="bg-navy/5 rounded-xl p-6 border border-navy/10">
            <h3 className="font-serif font-bold text-navy mb-3">Prayer</h3>
            <p className="text-text italic">{devotional.prayer}</p>
          </div>

          {/* Share */}
          <div className="flex items-center gap-4 mt-8 pt-8 border-t border-gray-100">
            <span className="text-sm font-medium text-text-light">Share:</span>
            {["Facebook", "Twitter", "Email"].map((platform) => (
              <button
                key={platform}
                className="text-sm text-navy hover:text-red transition-colors"
              >
                {platform}
              </button>
            ))}
          </div>
        </article>

        {/* Navigation */}
        <div className="flex justify-between mt-8">
          <button
            onClick={() => navigateDate(-1)}
            className="flex items-center gap-2 text-navy hover:text-red transition-colors font-medium"
          >
            <ChevronLeft className="w-4 h-4" /> Previous Day
          </button>
          <button
            onClick={() => navigateDate(1)}
            className="flex items-center gap-2 text-navy hover:text-red transition-colors font-medium"
          >
            Next Day <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
