"use client";

import { Suspense, useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { Search, Play, Headphones, BookOpen, ArrowRight } from "lucide-react";
import { EPISODES } from "@/data/episodes";
import { TRACKS } from "@/data/tracks";
import { DEVOTIONALS } from "@/data/devotionals";
import { HEALING_SCRIPTURES } from "@/data/index";

interface SearchResult {
  id: string;
  title: string;
  type: "video" | "audio" | "devotional" | "scripture";
  description: string;
  href: string;
}

function SearchContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<SearchResult[]>([]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const q = query.toLowerCase();
    const found: SearchResult[] = [];

    EPISODES.forEach((ep) => {
      if (
        ep.title.toLowerCase().includes(q) ||
        ep.description.toLowerCase().includes(q)
      ) {
        found.push({
          id: ep.id,
          title: ep.title,
          type: "video",
          description: ep.description,
          href: "/watch",
        });
      }
    });

    TRACKS.forEach((t) => {
      if (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      ) {
        found.push({
          id: t.id,
          title: t.title,
          type: "audio",
          description: t.description,
          href: "/listen",
        });
      }
    });

    Object.values(DEVOTIONALS).forEach((d) => {
      if (
        d.title.toLowerCase().includes(q) ||
        d.scripture.toLowerCase().includes(q) ||
        d.commentary.toLowerCase().includes(q)
      ) {
        found.push({
          id: d.date,
          title: d.title,
          type: "devotional",
          description: d.scripture,
          href: "/read",
        });
      }
    });

    HEALING_SCRIPTURES.forEach((s, i) => {
      if (
        s.reference.toLowerCase().includes(q) ||
        s.declaration.toLowerCase().includes(q) ||
        s.verse.toLowerCase().includes(q)
      ) {
        found.push({
          id: `healing-${i}`,
          title: s.reference,
          type: "scripture",
          description: s.declaration,
          href: "/healing",
        });
      }
    });

    setResults(found);
  }, [query]);

  const getIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Play className="w-5 h-5" />;
      case "audio":
        return <Headphones className="w-5 h-5" />;
      default:
        return <BookOpen className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "video":
        return "bg-red/10 text-red";
      case "audio":
        return "bg-navy/10 text-navy";
      case "devotional":
        return "bg-gold/20 text-gold-dark";
      default:
        return "bg-green-100 text-green-700";
    }
  };

  return (
    <div className="min-h-screen bg-cream">
      <div className="bg-navy py-16">
        <div className="max-w-3xl mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-serif text-white mb-6 text-center">
            Search
          </h1>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-light" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search teachings, devotionals, topics..."
              className="w-full pl-12 pr-4 py-4 border-0 rounded-full text-lg focus:outline-none focus:ring-2 focus:ring-gold shadow-lg"
              autoFocus
            />
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-12">
        {query.trim() && (
          <p className="text-text-light text-sm mb-6">
            {results.length} result{results.length !== 1 ? "s" : ""} for &quot;{query}&quot;
          </p>
        )}

        {results.length === 0 && query.trim() ? (
          <div className="text-center py-16 bg-white rounded-xl">
            <Search className="w-12 h-12 text-text-light/30 mx-auto mb-4" />
            <p className="text-text-light mb-2">No results found</p>
            <p className="text-sm text-text-light/60">
              Try different keywords or browse our{" "}
              <a href="/browse" className="text-red hover:underline">
                teaching library
              </a>
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {results.map((result) => (
              <a
                key={result.id}
                href={result.href}
                className="flex items-center gap-4 bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-navy/10 transition-all group"
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${getTypeColor(
                    result.type
                  )}`}
                >
                  {getIcon(result.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-text-light uppercase">
                      {result.type}
                    </span>
                  </div>
                  <h3 className="font-semibold text-dark group-hover:text-red transition-colors truncate">
                    {result.title}
                  </h3>
                  <p className="text-sm text-text-light truncate">
                    {result.description}
                  </p>
                </div>
                <ArrowRight className="w-5 h-5 text-text-light/30 group-hover:text-red shrink-0 transition-colors" />
              </a>
            ))}
          </div>
        )}

        {!query.trim() && (
          <div className="text-center py-16">
            <Search className="w-12 h-12 text-text-light/30 mx-auto mb-4" />
            <p className="text-text-light mb-4">
              Enter a search term to find teachings, devotionals, and more
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {["Faith", "Healing", "Grace", "Prayer", "Identity"].map((tag) => (
                <button
                  key={tag}
                  onClick={() => setQuery(tag)}
                  className="px-4 py-2 bg-white rounded-full text-sm text-navy hover:bg-navy/5 transition-colors border border-gray-200"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-cream flex items-center justify-center">
          <div className="text-text-light">Loading search...</div>
        </div>
      }
    >
      <SearchContent />
    </Suspense>
  );
}
