"use client";

import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, ChevronDown } from "lucide-react";
import { EPISODES, Episode } from "@/data/episodes";

const CATEGORIES = ["All", "TV", "Healing Journeys", "Destiny Stories", "Events"] as const;

export default function WatchPage() {
  const [selected, setSelected] = useState<Episode>(EPISODES[0]);
  const [category, setCategory] = useState<string>("All");
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showDropdown, setShowDropdown] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const filtered = category === "All"
    ? EPISODES
    : EPISODES.filter((ep) => ep.category === category.toLowerCase().replace(" ", ""));

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const updateProgress = () => {
      if (video.duration) setProgress((video.currentTime / video.duration) * 100);
    };
    video.addEventListener("timeupdate", updateProgress);
    return () => video.removeEventListener("timeupdate", updateProgress);
  }, [selected]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    isPlaying ? videoRef.current.pause() : videoRef.current.play();
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!videoRef.current) return;
    const time = (parseFloat(e.target.value) / 100) * videoRef.current.duration;
    videoRef.current.currentTime = time;
    setProgress(parseFloat(e.target.value));
  };

  const toggleFullscreen = () => {
    const container = document.getElementById("video-container");
    if (container) {
      document.fullscreenElement ? document.exitFullscreen() : container.requestFullscreen();
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      {/* Video Player */}
      <div className="bg-black">
        <div id="video-container" className="max-w-7xl mx-auto relative">
          <div className="aspect-video bg-dark relative group">
            <video
              ref={videoRef}
              key={selected.id}
              className="w-full h-full object-cover"
              poster={selected.thumbnail}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={() => setIsPlaying(false)}
            >
              <source src={selected.url} type="video/mp4" />
            </video>

            {/* Play overlay */}
            {!isPlaying && (
              <div
                className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
                onClick={togglePlay}
              >
                <div className="w-20 h-20 bg-red/90 rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-white ml-1" />
                </div>
              </div>
            )}

            {/* Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="flex items-center gap-4">
                <button onClick={togglePlay} className="text-white hover:text-gold transition-colors">
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={progress}
                  onChange={handleSeek}
                  className="flex-1 h-1 accent-red cursor-pointer"
                />
                <button
                  onClick={() => {
                    if (videoRef.current) videoRef.current.muted = !isMuted;
                    setIsMuted(!isMuted);
                  }}
                  className="text-white hover:text-gold transition-colors"
                >
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
                <button onClick={toggleFullscreen} className="text-white hover:text-gold transition-colors">
                  <Maximize className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Info + Episodes */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main info */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <span className="bg-red text-white text-xs font-semibold px-3 py-1 rounded-full uppercase">
                {selected.category}
              </span>
              <span className="text-white/50 text-sm">{selected.airDate}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-serif text-white mb-4">{selected.title}</h1>
            <p className="text-white/70 mb-6">{selected.description}</p>

            <div className="flex gap-4">
              <button className="flex items-center gap-2 bg-red hover:bg-red-dark text-white px-6 py-3 rounded-full font-semibold transition-colors">
                <Play className="w-5 h-5" /> Watch Again
              </button>
              <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-full font-semibold transition-colors">
                Share
              </button>
            </div>
          </div>

          {/* Episode List */}
          <div className="bg-white/5 rounded-xl p-4">
            <div className="relative mb-4">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="w-full flex items-center justify-between bg-white/10 text-white px-4 py-3 rounded-lg text-sm font-medium"
              >
                {category}
                <ChevronDown className={`w-4 h-4 transition-transform ${showDropdown ? "rotate-180" : ""}`} />
              </button>
              {showDropdown && (
                <div className="absolute top-full left-0 right-0 bg-dark border border-white/10 rounded-lg mt-1 z-10">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => {
                        setCategory(cat);
                        setShowDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-2.5 text-sm hover:bg-white/10 transition-colors ${
                        category === cat ? "text-gold" : "text-white"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
              {filtered.map((ep) => (
                <button
                  key={ep.id}
                  onClick={() => {
                    setSelected(ep);
                    setIsPlaying(false);
                    setProgress(0);
                  }}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors ${
                    selected.id === ep.id
                      ? "bg-red/20 border border-red/30"
                      : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  <div className="w-16 h-10 bg-navy/50 rounded flex items-center justify-center shrink-0">
                    <Play className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white truncate">{ep.title}</div>
                    <div className="text-xs text-white/50">{ep.duration}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
