import Link from "next/link";
import { Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-navy text-white">
      {/* CTA Strip */}
      <div className="bg-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <h3 className="font-serif text-xl md:text-2xl font-bold">
              You can make a difference
            </h3>
            <p className="text-white/80 mt-1 text-sm">
              Support the Gospel Truth ministry worldwide
            </p>
          </div>
          <Link
            href="/give"
            className="inline-flex items-center gap-2 bg-white text-red hover:bg-cream px-8 py-3 rounded-full font-bold text-sm transition-colors shadow-lg"
          >
            <Heart className="w-4 h-4" /> Give Today
          </Link>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 md:gap-6">
          {/* Logo + Signup */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-9 h-9 bg-red rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">AW</span>
              </div>
              <div className="leading-tight">
                <div className="font-serif font-bold text-[13px]">
                  Andrew Wommack
                </div>
                <div className="text-[8px] tracking-[0.15em] text-white/50 uppercase">
                  Ministries
                </div>
              </div>
            </div>
            <div className="mt-5">
              <h4 className="font-semibold text-xs mb-2">Sign up to receive</h4>
              <p className="text-[11px] text-white/60 mb-3">inspiring testimonies and news</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 min-w-0 px-3 py-2 text-xs bg-white/10 border border-white/20 rounded-l-md text-white placeholder:text-white/40 focus:outline-none focus:border-gold"
                />
                <button className="bg-red hover:bg-red-dark px-3 py-2 text-xs font-semibold rounded-r-md transition-colors shrink-0">
                  →
                </button>
              </div>
            </div>
          </div>

          {/* Explore */}
          <div>
            <h4 className="font-semibold text-xs mb-4">Explore</h4>
            <ul className="space-y-2.5">
              {[
                { name: "Home", href: "/" },
                { name: "Watch", href: "/watch" },
                { name: "Listen", href: "/listen" },
                { name: "Read", href: "/read" },
                { name: "Healing", href: "/healing" },
                { name: "About", href: "/about" },
              ].map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="text-xs text-white/60 hover:text-gold transition-colors"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold text-xs mb-4">Resources</h4>
            <ul className="space-y-2.5">
              {["Browse Teachings", "Devotionals", "Living Commentary", "Healing Guide", "Articles"].map(
                (item) => (
                  <li key={item}>
                    <Link
                      href="/browse"
                      className="text-xs text-white/60 hover:text-gold transition-colors"
                    >
                      {item}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Partner */}
          <div>
            <h4 className="font-semibold text-xs mb-4">Partner</h4>
            <ul className="space-y-2.5">
              {["Give Now", "Partner Login", "Account Settings", "Tax Receipts"].map(
                (item) => (
                  <li key={item}>
                    <Link
                      href="/give"
                      className="text-xs text-white/60 hover:text-gold transition-colors"
                    >
                      {item}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-semibold text-xs mb-4">Connect</h4>
            <ul className="space-y-2.5">
              {["Facebook", "YouTube", "Instagram", "Twitter", "Contact Us"].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="text-xs text-white/60 hover:text-gold transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-white/40">
          <p>&copy; {new Date().getFullYear()} Andrew Wommack Ministries. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
