"use client";

import Link from "next/link";
import { useState, useEffect, useRef } from "react";
import {
  Menu,
  X,
  Play,
  Headphones,
  BookOpen,
  Heart,
  DollarSign,
  Info,
  Search,
  ChevronDown,
  MapPin,
  ArrowRight,
} from "lucide-react";
import { NAV_ITEMS } from "@/data/nav";

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const handleMouseEnter = (title: string) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setActiveDropdown(title);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setActiveDropdown(null), 150);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
      setSearchOpen(false);
      setSearchQuery("");
    }
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "play": return <Play className="w-5 h-5" />;
      case "headphones": return <Headphones className="w-5 h-5" />;
      case "book": return <BookOpen className="w-5 h-5" />;
      case "heart": return <Heart className="w-5 h-5" />;
      case "dollar": return <DollarSign className="w-5 h-5" />;
      case "info": return <Info className="w-5 h-5" />;
      case "arrow": return <ArrowRight className="w-5 h-5" />;
      default: return <ArrowRight className="w-5 h-5" />;
    }
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-md"
          : "bg-white shadow-sm"
      }`}
    >
      {/* Top Bar */}
      <div className="bg-navy text-white hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-8 text-[11px]">
            <div className="flex items-center gap-5">
              <a href="#" className="hover:text-gold transition-colors">AWM+TV</a>
              <a href="#" className="hover:text-gold transition-colors">GTN Channel</a>
              <a href="#" className="hover:text-gold transition-colors flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Charis Bible College
              </a>
            </div>
            <div className="flex items-center gap-5">
              <a href="#" className="hover:text-gold transition-colors">Truth & Liberty</a>
              <a href="#" className="hover:text-gold transition-colors">ARMI</a>
              <a href="#" className="hover:text-gold transition-colors font-medium">Give Now</a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-[72px]">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 md:w-11 md:h-11 bg-red rounded-full flex items-center justify-center shadow-sm">
              <span className="text-white font-bold text-base md:text-lg">AW</span>
            </div>
            <div className="hidden sm:block leading-tight">
              <div className="font-serif font-bold text-navy text-[15px]">
                Andrew Wommack
              </div>
              <div className="text-[9px] text-text-light tracking-[0.15em] uppercase font-medium">
                Ministries
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-0.5">
            {NAV_ITEMS.map((item) => (
              <div
                key={item.title}
                className="relative"
                onMouseEnter={() => handleMouseEnter(item.title)}
                onMouseLeave={handleMouseLeave}
              >
                <Link
                  href={item.href}
                  className={`flex items-center gap-1 px-3 py-2 text-[13px] font-medium transition-colors rounded-lg ${
                    activeDropdown === item.title
                      ? "text-red bg-red/5"
                      : "text-dark hover:text-red hover:bg-red/5"
                  }`}
                >
                  {item.title}
                  {item.children && (
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform duration-200 ${
                        activeDropdown === item.title ? "rotate-180" : ""
                      }`}
                    />
                  )}
                </Link>

                {/* Mega Menu */}
                {item.children && activeDropdown === item.title && (
                  <div
                    className="absolute top-full left-1/2 -translate-x-1/2 pt-2"
                    onMouseEnter={() => handleMouseEnter(item.title)}
                    onMouseLeave={handleMouseLeave}
                  >
                    <div className="bg-white rounded-xl shadow-xl border border-gray-100 p-5 min-w-[480px]">
                      <div className="grid grid-cols-2 gap-2">
                        {item.children.map((child) => (
                          <Link
                            key={child.title}
                            href={child.href}
                            className="flex items-start gap-3 p-3 rounded-lg hover:bg-cream transition-colors group"
                          >
                            <div className="w-9 h-9 rounded-lg bg-navy/5 flex items-center justify-center shrink-0 group-hover:bg-red/10 transition-colors text-navy group-hover:text-red">
                              {getIcon(child.icon)}
                            </div>
                            <div className="min-w-0">
                              <div className="font-semibold text-[13px] text-dark group-hover:text-red transition-colors">
                                {child.title}
                              </div>
                              <div className="text-[11px] text-text-light mt-0.5 leading-snug">
                                {child.description}
                              </div>
                            </div>
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2.5 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Search"
            >
              <Search className="w-[18px] h-[18px] text-navy" />
            </button>
            <Link
              href="/give"
              className="hidden sm:flex items-center gap-1.5 bg-red hover:bg-red-dark text-white px-5 py-2.5 rounded-full text-[13px] font-semibold transition-colors shadow-sm"
            >
              <Heart className="w-3.5 h-3.5" /> Give
            </Link>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2.5 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Toggle menu"
            >
              {mobileOpen ? (
                <X className="w-5 h-5 text-navy" />
              ) : (
                <Menu className="w-5 h-5 text-navy" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      {searchOpen && (
        <div className="border-t border-gray-100 bg-white py-4">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-light" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search teachings, devotionals, topics..."
                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-full text-sm focus:outline-none focus:border-navy focus:ring-1 focus:ring-navy"
                autoFocus
              />
            </form>
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-gray-100 bg-white max-h-[75vh] overflow-y-auto">
          <div className="px-4 py-4 space-y-1">
            {NAV_ITEMS.map((item) => (
              <div key={item.title}>
                <Link
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-dark hover:bg-cream rounded-lg transition-colors"
                >
                  <span className="text-red">{getIcon(item.icon || "arrow")}</span>
                  {item.title}
                </Link>
                {item.children && (
                  <div className="pl-11 pb-2 space-y-0.5">
                    {item.children.map((child) => (
                      <Link
                        key={child.title}
                        href={child.href}
                        onClick={() => setMobileOpen(false)}
                        className="block px-4 py-2 text-[13px] text-text-light hover:text-red transition-colors"
                      >
                        {child.title}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-4 mt-2 border-t border-gray-100">
              <Link
                href="/give"
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-center gap-2 bg-red text-white px-5 py-3 rounded-full text-sm font-semibold w-full"
              >
                <Heart className="w-4 h-4" /> Give Now
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
