export interface Devotional {
  date: string;
  title: string;
  scripture: string;
  verseText: string;
  commentary: string;
  prayer: string;
}

export const DEVOTIONALS: Record<string, Devotional> = {
  '2026-08-24': {
    date: '2026-08-24',
    title: 'Unconditional Love Manifested',
    scripture: 'Romans 5:8',
    verseText: '"But God commendeth his love toward us, in that, while we were yet sinners, Christ died for us."',
    commentary: 'Most people find it hard to believe that God loves them independently of their actions. We are conditioned by this world to receive rewards based on performance. But God\'s love is not like that. He did not wait for you to clean up your act before sending Jesus. He loved you at your absolute worst.',
    prayer: 'Father, thank You for loving me even when I was far from You. I receive Your grace today, knowing that I do not have to earn Your affection. I rest in Your unconditional favor. Amen.',
  },
  '2026-08-25': {
    date: '2026-08-25',
    title: 'Already Provided',
    scripture: '1 Peter 2:24',
    verseText: '"Who his own self bare our sins in his own body on the tree, that we, being dead to sins, should live unto righteousness: by whose stripes ye were healed."',
    commentary: 'Notice the tense: you *were* healed. It does not say you *will be* healed. Healing is not a future event that you have to beg God to perform; it is a past-tense reality completed at the cross.',
    prayer: 'Thank You, Jesus, that by Your stripes I was healed. I command my body to align with the truth of Your word. I release Your healing power into my cells right now. Amen.',
  },
  '2026-08-26': {
    date: '2026-08-26',
    title: 'Renewing the Mirror',
    scripture: 'Romans 12:2',
    verseText: '"And be not conformed to this world: but be ye transformed by the renewing of your mind."',
    commentary: 'Your spirit is identical to Jesus—righteous, holy, and full of power. However, if your mind is still conformed to the thinking of this world, the power in your spirit remains locked away.',
    prayer: 'Lord, I choose to meditate on Your Word today. I refuse to conform to the fear, sickness, and lack of this world. I renew my mind to think like Christ. Amen.',
  },
  '2026-08-27': {
    date: '2026-08-27',
    title: 'Righteousness is a Gift',
    scripture: '2 Corinthians 5:21',
    verseText: '"For he hath made him to be sin for us, who knew no sin; that we might be made the righteousness of God in him."',
    commentary: 'Righteousness is not a level of holiness that you achieve through good behavior. It is a gift of standing that you receive at the moment of new birth.',
    prayer: 'Father, thank You for the gift of righteousness. I declare that I am the righteousness of God in Christ. I stand before You bold, blameless, and deeply loved. Amen.',
  },
};

export const getDevotionalForDate = (dateString: string): Devotional => {
  if (DEVOTIONALS[dateString]) return DEVOTIONALS[dateString];
  
  const day = parseInt(dateString.split('-')[2]) || 1;
  return {
    date: dateString,
    title: `Grace Foundations: Day ${day}`,
    scripture: 'Galatians 2:20',
    verseText: '"I am crucified with Christ: nevertheless I live; yet not I, but Christ liveth in me."',
    commentary: `Walking in faith is not about mustering up human strength. It is about letting the Christ inside you live His life through you. Today, remember that you are united with Christ.`,
    prayer: 'Jesus, I surrender my self-effort. Live Your life through me today. I walk in Your confidence and faith. Amen.',
  };
};
