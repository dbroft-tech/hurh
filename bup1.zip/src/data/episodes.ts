export interface Episode {
  id: string;
  title: string;
  category: 'tv' | 'healing' | 'destiny' | 'events';
  duration: string;
  url: string;
  thumbnail: string;
  description: string;
  airDate: string;
}

export const EPISODES: Episode[] = [
  {
    id: 'ep1',
    title: "Gospel Truth: God's Will is Healing (Part 1)",
    category: 'tv',
    duration: '28:15',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumbnail: '/images/hero.jpg',
    description: "In this teaching, Andrew Wommack shares how God's will is always healing. Learn how Jesus paid for your sicknesses and diseases on the cross.",
    airDate: 'August 25, 2026',
  },
  {
    id: 'ep2',
    title: "Healing Journeys: Lance's Restoration from Liver Failure",
    category: 'healing',
    duration: '15:40',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumbnail: '/images/healing.jpg',
    description: "Doctors gave Lance weeks to live due to critical liver failure. By listening to Andrew's teaching, his body was completely transformed.",
    airDate: 'August 20, 2026',
  },
  {
    id: 'ep3',
    title: "Destiny Stories: Anchored in Woodland Mountains",
    category: 'destiny',
    duration: '22:10',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: '/images/destiny.jpg',
    description: "Follow students discovering their God-given destiny at Charis Bible College in the Rocky Mountains.",
    airDate: 'August 15, 2026',
  },
  {
    id: 'ep4',
    title: "Truth & Liberty Coalition: Healing Our Land",
    category: 'events',
    duration: '45:30',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    thumbnail: '/images/events.jpg',
    description: "Highlights from the national truth summit exploring how faith and governance intersect.",
    airDate: 'August 10, 2026',
  },
  {
    id: 'ep5',
    title: "Gospel Truth: The Power of Unconditional Grace",
    category: 'tv',
    duration: '27:50',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    thumbnail: '/images/hero.jpg',
    description: "Andrew reveals how God's love does not depend on your performance, but on Jesus' finished work.",
    airDate: 'August 5, 2026',
  },
  {
    id: 'ep6',
    title: "Healing Journeys: Hannah's Eyesight Restored",
    category: 'healing',
    duration: '18:25',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    thumbnail: '/images/healing.jpg',
    description: "Diagnosed with progressive macular degeneration, Hannah was losing her sight. Discover how faith restored her vision.",
    airDate: 'July 30, 2026',
  },
];
