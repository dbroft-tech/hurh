export interface ScriptureDeclaration {
  reference: string;
  verse: string;
  declaration: string;
  category: 'general' | 'terminal' | 'chronic' | 'mental';
}

export const HEALING_SCRIPTURES: ScriptureDeclaration[] = [
  {
    reference: 'Isaiah 53:5',
    verse: '"But he was wounded for our transgressions, he was bruised for our iniquities: the chastisement of our peace was upon him; and with his stripes we are healed."',
    declaration: 'Jesus took my sicknesses and carried my diseases. By His stripes, I was healed. Healing belongs to me right now.',
    category: 'general',
  },
  {
    reference: 'Proverbs 4:20-22',
    verse: '"My son, attend to my words; incline thine ear unto my sayings... For they are life unto those that find them, and health to all their flesh."',
    declaration: 'God\'s word is medicine to my physical flesh. I attend to it, meditate on it, and it brings health to every cell in my body.',
    category: 'chronic',
  },
  {
    reference: 'Romans 8:11',
    verse: '"But if the Spirit of him that raised up Jesus from the dead dwell in you, he that raised up Christ from the dead shall also quicken your mortal bodies."',
    declaration: 'The same Holy Spirit who raised Jesus from the grave lives in me. He is currently quickening, restoring, and vitalizing my physical body.',
    category: 'terminal',
  },
  {
    reference: '2 Timothy 1:7',
    verse: '"For God hath not given us the spirit of fear; but of power, and of love, and of a sound mind."',
    declaration: 'I refuse depression, anxiety, and fear. God has gifted me with power, unconditional love, and a perfectly sound mind.',
    category: 'mental',
  },
  {
    reference: 'Psalms 103:2-3',
    verse: '"Bless the LORD, O my soul, and forget not all his benefits: Who forgiveth all thine iniquities; who healeth all thy diseases;"',
    declaration: 'I declare that healing all my diseases is a direct benefit of my covenant with God. My body is clean, strong, and fully restored.',
    category: 'general',
  },
];

export interface CommentaryNote {
  reference: string;
  verse: string;
  greekNote?: string;
  note: string;
}

export const COMMENTARY_DB: Record<string, CommentaryNote> = {
  'john 3:16': {
    reference: 'John 3:16',
    verse: '"For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life."',
    greekNote: 'The Greek word for loved here is "agapao", representing a divine, self-sacrificing, unconditional love based on the character of the giver, not the merit of the recipient.',
    note: 'Many focus on the word "perish" and use this verse to preach fear. But the primary focus is God\'s motivation: love. God gave Jesus because He loved the world.',
  },
  'romans 8:1': {
    reference: 'Romans 8:1',
    verse: '"There is therefore now no condemnation to them which are in Christ Jesus."',
    greekNote: 'The Greek "katakrima" (condemnation) refers to a judicial sentence of punishment. In Christ, that sentence is entirely abolished.',
    note: 'In the oldest manuscripts, the phrase "who walk not after the flesh" is not present in verse 1. There is simply *no condemnation* for those in Christ Jesus, period.',
  },
  'galatians 2:20': {
    reference: 'Galatians 2:20',
    verse: '"I am crucified with Christ: nevertheless I live; yet not I, but Christ liveth in me..."',
    greekNote: 'Crucified here is "systauroo", meaning jointly crucified or completely identified with Christ\'s death on the cross.',
    note: 'When Jesus died, your old self died with Him. You do not have to "die to self" daily. The old man is already dead; your job is to reckon him dead and let the new creation spirit take charge.',
  },
};

export interface Tier {
  name: string;
  minAmount: number;
  maxAmount: number;
  badge: string;
  benefits: string[];
}

export const TIERS: Tier[] = [
  {
    name: 'Grace Partner',
    minAmount: 10,
    maxAmount: 29,
    badge: 'Grace Circle',
    benefits: [
      'Monthly Andrew Wommack Newsletter',
      'Partner Devotional booklet (quarterly)',
      'Personal prayer agreement support',
    ],
  },
  {
    name: 'Gospel Truth Partner',
    minAmount: 30,
    maxAmount: 99,
    badge: 'Gospel Envoy',
    benefits: [
      'All Grace Partner benefits',
      '15% discount on all resources',
      'Exclusive monthly teaching MP3 download',
      'Online access to study commentaries',
    ],
  },
  {
    name: 'Pillar Partner',
    minAmount: 100,
    maxAmount: 299,
    badge: 'Ministry Pillar',
    benefits: [
      'All Gospel Truth Partner benefits',
      'Full premium Living Commentary access',
      'Complimentary study guides',
      'Reserved VIP seating at conferences',
    ],
  },
  {
    name: 'Foundation Pillar',
    minAmount: 300,
    maxAmount: 1000,
    badge: 'Foundation Circle',
    benefits: [
      'All Pillar Partner benefits',
      'Autographed Leather Study Bible',
      'Annual Woodland Park Ranch banquet',
      'Quarterly video conference briefings',
    ],
  },
];

export interface Ministry {
  name: string;
  description: string;
  url: string;
  image: string;
}

export const MINISTRIES: Ministry[] = [
  {
    name: 'Charis Bible College',
    description: 'Located in Woodland Park, Colorado. Discover your destiny and prepare for ministry with strong biblical foundations.',
    url: 'https://www.charisbiblecollege.org',
    image: '/images/charis.jpg',
  },
  {
    name: 'Truth & Liberty Coalition',
    description: 'Educating, unifying, and activating believers to impact culture and reform government.',
    url: 'https://truthandliberty.net',
    image: '/images/truth-liberty.jpg',
  },
  {
    name: 'Gospel Truth Network',
    description: 'Watch GTN today for uplifting programs broadcasting truth 24/7.',
    url: 'https://gtntv.com',
    image: '/images/gtn.jpg',
  },
  {
    name: 'ARMI',
    description: 'Join ARMI for connection and ministry growth worldwide.',
    url: 'https://www.armi.net',
    image: '/images/armi.jpg',
  },
  {
    name: 'Construction Updates',
    description: 'See the expansion of Charis Bible College campus.',
    url: 'https://www.foundationbuilder.org',
    image: '/images/construction.jpg',
  },
];

export interface Testimonial {
  name: string;
  location: string;
  quote: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'C.H.',
    location: 'Sioux City, Iowa',
    quote: 'Andrew, his books and audio teachings have helped me grow so much in my spirituality. You are so good at helping people understand the truth of things.',
  },
  {
    name: 'L.D.',
    location: 'Romania',
    quote: 'Since I discovered Andrew\'s teachings 7 months ago, my life completely changed. I fell in love with God\'s Word, and I began believing for healing, prosperity and victorious life.',
  },
  {
    name: 'E.E.A.',
    location: 'Nigeria',
    quote: 'I want to thank God who has used this ministry to correct a lot of wrong perceptions about Him and His ways, paving the way for me to experience the fullness and miracles of God.',
  },
];

export interface Topic {
  name: string;
  icon: string;
  count: number;
}

export const TOPICS: Topic[] = [
  { name: 'Bible Studies', icon: '📖', count: 24 },
  { name: 'Faith', icon: '✝️', count: 18 },
  { name: 'Finances', icon: '💰', count: 12 },
  { name: 'God-Given Purpose', icon: '🎯', count: 15 },
  { name: 'Grace', icon: '❤️', count: 20 },
  { name: 'Healing', icon: '🏥', count: 16 },
  { name: 'Holy Spirit', icon: '🔥', count: 14 },
  { name: 'Identity in Christ', icon: '👤', count: 11 },
  { name: 'Personal Relationships', icon: '💑', count: 9 },
  { name: 'Prayer', icon: '🙏', count: 13 },
  { name: 'Victorious Living', icon: '🏆', count: 17 },
];
