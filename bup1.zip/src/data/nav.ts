export interface NavItem {
  title: string;
  href: string;
  icon?: string;
  children?: {
    title: string;
    href: string;
    icon: string;
    description: string;
  }[];
}

export const NAV_ITEMS: NavItem[] = [
  {
    title: "Watch",
    href: "/watch",
    icon: "play",
    children: [
      {
        title: "Gospel Truth TV",
        href: "/watch/tv",
        icon: "play",
        description: "Andrew's flagship teaching program",
      },
      {
        title: "Healing Journeys",
        href: "/watch/healing-journeys",
        icon: "heart",
        description: "Real testimonies from people healed",
      },
      {
        title: "Destiny Stories",
        href: "/watch/destiny-stories",
        icon: "arrow",
        description: "Students discovering their God-given purpose",
      },
      {
        title: "Events",
        href: "/watch/events",
        icon: "play",
        description: "Conference highlights and special events",
      },
    ],
  },
  {
    title: "Listen",
    href: "/listen",
    icon: "headphones",
    children: [
      {
        title: "Teaching Library",
        href: "/listen/library",
        icon: "headphones",
        description: "Hundreds of free audio teachings",
      },
      {
        title: "Podcasts",
        href: "/listen/podcasts",
        icon: "headphones",
        description: "Subscribe to audio devotionals",
      },
      {
        title: "Topics",
        href: "/listen/topics",
        icon: "book",
        description: "Browse by subject",
      },
    ],
  },
  {
    title: "Read",
    href: "/read",
    icon: "book",
    children: [
      {
        title: "Devotionals",
        href: "/read/devotionals",
        icon: "book",
        description: "Daily truth for your walk",
      },
      {
        title: "Living Commentary",
        href: "/read/commentary",
        icon: "book",
        description: "Andrew's personal study notes",
      },
      {
        title: "Articles",
        href: "/read/articles",
        icon: "book",
        description: "Topical writings on faith",
      },
    ],
  },
  {
    title: "Healing",
    href: "/healing",
    icon: "heart",
    children: [
      {
        title: "Healing Journey TV",
        href: "/healing/journeys",
        icon: "play",
        description: "Video testimonies",
      },
      {
        title: "Scripture Guide",
        href: "/healing/scriptures",
        icon: "book",
        description: "Healing promises and declarations",
      },
      {
        title: "Healing Testimonies",
        href: "/healing/testimonies",
        icon: "heart",
        description: "Written accounts from viewers",
      },
    ],
  },
  {
    title: "Give",
    href: "/give",
    icon: "dollar",
  },
  {
    title: "About",
    href: "/about",
    icon: "info",
    children: [
      {
        title: "About Andrew",
        href: "/about/andrew",
        icon: "info",
        description: "Biography and calling",
      },
      {
        title: "Ministry Overview",
        href: "/about/ministry",
        icon: "info",
        description: "Our mission and global reach",
      },
      {
        title: "Our Ministries",
        href: "/about/ministries",
        icon: "arrow",
        description: "Network of partner ministries",
      },
      {
        title: "Living Commentary",
        href: "/read/commentary",
        icon: "book",
        description: "Study tool resources",
      },
    ],
  },
];
