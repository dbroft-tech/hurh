export interface Track {
  id: string;
  title: string;
  speaker: string;
  url: string;
  coverUrl: string;
  duration: string;
  category: string;
  description: string;
  year: string;
}

export const TRACKS: Track[] = [
  {
    id: 'aud1',
    title: 'Spirit, Soul & Body: Part 1',
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    coverUrl: '/images/hero.jpg',
    duration: '42:18',
    category: 'Spirit, Soul & Body',
    description: 'Understand the relational structure of your spirit, soul, and body. Learn how your spirit was instantly perfected at salvation.',
    year: '2025',
  },
  {
    id: 'aud2',
    title: 'Spirit, Soul & Body: Part 2',
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    coverUrl: '/images/hero.jpg',
    duration: '45:30',
    category: 'Spirit, Soul & Body',
    description: 'Deep dive into why your physical senses compete with your born-again spirit.',
    year: '2025',
  },
  {
    id: 'aud3',
    title: "The Believer's Authority: Part 1",
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    coverUrl: '/images/events.jpg',
    duration: '38:10',
    category: "Believer's Authority",
    description: 'Explore the authority God has delegated to you as a believer.',
    year: '2026',
  },
  {
    id: 'aud4',
    title: "The Believer's Authority: Part 2",
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    coverUrl: '/images/events.jpg',
    duration: '40:15',
    category: "Believer's Authority",
    description: 'How to stand against satanic operations and enforce Jesus triumph.',
    year: '2026',
  },
  {
    id: 'aud5',
    title: "You've Already Got It!: Part 1",
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    coverUrl: '/images/destiny.jpg',
    duration: '44:50',
    category: "You've Already Got It",
    description: 'Learn that God has already blessed you with all spiritual blessings in Christ Jesus.',
    year: '2024',
  },
  {
    id: 'aud6',
    title: "You've Already Got It!: Part 2",
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    coverUrl: '/images/destiny.jpg',
    duration: '43:10',
    category: "You've Already Got It",
    description: 'How to bypass unbelief and clear the channel of faith.',
    year: '2024',
  },
  {
    id: 'aud7',
    title: 'A Better Way to Pray: Part 1',
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    coverUrl: '/images/hero.jpg',
    duration: '37:40',
    category: 'Prayer & Communion',
    description: 'Discover how prayer is not about twisting God\'s arm, but about communion.',
    year: '2025',
  },
  {
    id: 'aud8',
    title: 'A Better Way to Pray: Part 2',
    speaker: 'Andrew Wommack',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    coverUrl: '/images/hero.jpg',
    duration: '39:55',
    category: 'Prayer & Communion',
    description: 'Commanding prayer vs pleading prayer. Harness the power of faith.',
    year: '2025',
  },
];
